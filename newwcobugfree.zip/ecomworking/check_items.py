import os
import django

# Setup Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'ecom.settings')
django.setup()

from dashboard.models import Item

print("Available items:")
items = Item.objects.all()[:10]
for item in items:
    print(f"ID: {item.id}, Name: {item.name}")

if not items:
    print("No items found in database")
else:
    print(f"\nTotal items: {Item.objects.count()}")
    print(f"First item ID: {items[0].id}") 