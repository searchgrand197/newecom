# Customer Login API with Cart Details

This document shows how to use the updated customer login API that now includes cart information in the response.

## API Endpoint

```
POST /api/customer/login/
```

## Request Format

```json
{
  "username": "customer_username",
  "password": "customer_password"
}
```

## Response Format (Updated)

The API now returns cart details along with user information:

```json
{
  "status": "success",
  "message": "Login successful",
  "access_token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9...",
  "refresh_token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9...",
  "customer_id": 123,
  "user_details": {
    "id": 123,
    "username": "customer_username",
    "email": "customer@example.com",
    "customer_name": "Customer Name",
    "customer_phone": "1234567890",
    "wallet_amount": "100.00"
  },
  "cart_details": {
    "total_items": 5,
    "cart_items": [
      {
        "id": 1,
        "item_id": 456,
        "item_name": "Product Name",
        "item_sku": "SKU123",
        "item_price": "99.99",
        "item_image": "http://example.com/media/subcategory_images/product.jpg",
        "quantity": 2,
        "total_price": "199.98"
      }
    ],
    "cart_count": 1
  }
}
```

## Cart Details Structure

### cart_details Object
- **total_items**: Total quantity of all items in cart
- **cart_items**: Array of cart items with full details
- **cart_count**: Number of unique items in cart

### cart_items Array Elements
- **id**: Cart item ID
- **item_id**: Product ID
- **item_name**: Product name
- **item_sku**: Product SKU
- **item_price**: Product price
- **item_image**: Full URL to product image (if available)
- **quantity**: Quantity of this item in cart
- **total_price**: Calculated total price (price × quantity)

## Usage Examples

### 1. cURL Example

```bash
# Login existing user
curl -X POST http://localhost:8000/api/customer/login/ \
  -H "Content-Type: application/json" \
  -d '{
    "username": "testuser",
    "password": "testpass123"
  }'

# Create new user (auto-register)
curl -X POST http://localhost:8000/api/customer/login/ \
  -H "Content-Type: application/json" \
  -d '{
    "username": "newuser",
    "password": "newpass123"
  }'
```

### 2. JavaScript/Fetch Example

```javascript
// Login function
async function customerLogin(username, password) {
  try {
    const response = await fetch('/api/customer/login/', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        username: username,
        password: password
      })
    });

    const data = await response.json();
    
    if (data.status === 'success') {
      // Store tokens
      localStorage.setItem('access_token', data.access_token);
      localStorage.setItem('refresh_token', data.refresh_token);
      localStorage.setItem('customer_id', data.customer_id);
      
      // Handle cart details
      const cartDetails = data.cart_details;
      console.log('Cart Items:', cartDetails.cart_items);
      console.log('Total Items:', cartDetails.total_items);
      console.log('Cart Count:', cartDetails.cart_count);
      
      // Update UI with cart information
      updateCartUI(cartDetails);
      
      return data;
    } else {
      throw new Error(data.message);
    }
  } catch (error) {
    console.error('Login failed:', error);
    throw error;
  }
}

// Update cart UI function
function updateCartUI(cartDetails) {
  const cartCount = document.getElementById('cart-count');
  const cartItems = document.getElementById('cart-items');
  
  if (cartCount) {
    cartCount.textContent = cartDetails.total_items;
  }
  
  if (cartItems) {
    cartItems.innerHTML = '';
    cartDetails.cart_items.forEach(item => {
      const itemElement = document.createElement('div');
      itemElement.innerHTML = `
        <div class="cart-item">
          <img src="${item.item_image || '/default-image.jpg'}" alt="${item.item_name}">
          <div class="item-details">
            <h4>${item.item_name}</h4>
            <p>SKU: ${item.item_sku}</p>
            <p>Quantity: ${item.quantity}</p>
            <p>Price: ₹${item.item_price}</p>
            <p>Total: ₹${item.total_price}</p>
          </div>
        </div>
      `;
      cartItems.appendChild(itemElement);
    });
  }
}

// Usage
customerLogin('testuser', 'testpass123')
  .then(data => {
    console.log('Login successful:', data);
  })
  .catch(error => {
    console.error('Login failed:', error);
  });
```

### 3. Python Requests Example

```python
import requests
import json

def customer_login(username, password, base_url="http://localhost:8000"):
    """
    Login customer and get cart details
    """
    url = f"{base_url}/api/customer/login/"
    data = {
        "username": username,
        "password": password
    }
    
    try:
        response = requests.post(url, json=data)
        response.raise_for_status()
        
        result = response.json()
        
        if result['status'] == 'success':
            # Extract cart details
            cart_details = result.get('cart_details', {})
            
            print(f"Login successful for user: {result['user_details']['username']}")
            print(f"Cart has {cart_details.get('total_items', 0)} total items")
            print(f"Cart has {cart_details.get('cart_count', 0)} unique items")
            
            # Display cart items
            for item in cart_details.get('cart_items', []):
                print(f"  - {item['item_name']} (x{item['quantity']}) - ₹{item['total_price']}")
            
            return result
        else:
            print(f"Login failed: {result.get('message', 'Unknown error')}")
            return None
            
    except requests.exceptions.RequestException as e:
        print(f"Request failed: {e}")
        return None

# Usage examples
if __name__ == "__main__":
    # Test existing user
    print("Testing existing user login:")
    customer_login("testuser", "testpass123")
    
    print("\n" + "="*50 + "\n")
    
    # Test new user (auto-register)
    print("Testing new user auto-registration:")
    customer_login("newuser123", "newpass123")
```

## Response Status Codes

- **200**: Existing user login successful
- **201**: New user created and logged in successfully
- **400**: Bad request (missing username/password)
- **401**: Invalid credentials
- **500**: Server error

## Cart Details for Different Scenarios

### Existing User with Items in Cart
```json
{
  "cart_details": {
    "total_items": 5,
    "cart_items": [
      {
        "id": 1,
        "item_id": 456,
        "item_name": "Smartphone",
        "item_sku": "PHONE001",
        "item_price": "15000.00",
        "item_image": "http://localhost:8000/media/subcategory_images/phone.jpg",
        "quantity": 1,
        "total_price": "15000.00"
      },
      {
        "id": 2,
        "item_id": 789,
        "item_name": "Laptop",
        "item_sku": "LAPTOP001",
        "item_price": "45000.00",
        "item_image": "http://localhost:8000/media/subcategory_images/laptop.jpg",
        "quantity": 2,
        "total_price": "90000.00"
      }
    ],
    "cart_count": 2
  }
}
```

### New User (Empty Cart)
```json
{
  "cart_details": {
    "total_items": 0,
    "cart_items": [],
    "cart_count": 0
  }
}
```

## Benefits of This Update

1. **Single API Call**: Get user details and cart information in one request
2. **Reduced Network Traffic**: No need for separate cart API calls
3. **Better UX**: Frontend can immediately display cart information
4. **Consistent Data**: Cart data is fetched at the same time as user authentication
5. **Backward Compatible**: Existing API consumers still work

## Error Handling

The API maintains backward compatibility. If cart details cannot be fetched, the API will still return user details:

```json
{
  "status": "success",
  "message": "Login successful",
  "access_token": "...",
  "refresh_token": "...",
  "customer_id": 123,
  "user_details": {
    // ... user details
  },
  "cart_details": {
    "total_items": 0,
    "cart_items": [],
    "cart_count": 0
  }
}
``` 