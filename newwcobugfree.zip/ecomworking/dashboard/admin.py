from django.contrib import admin
from .models import Category, Subcategory, Keyword, Item, ItemImage, Affiliate, AffiliateLink, Order, ItemVariant, AffiliateLogin, OrderDashboard, OrderDashboardItem
from rating.models import Rating
from django.db.models import Avg, Count
from django import forms

# Custom form for Item admin
class ItemAdminForm(forms.ModelForm):
    class Meta:
        model = Item
        fields = '__all__'
    
    def clean_video(self):
        video = self.cleaned_data.get('video')
        if video and hasattr(video, 'content_type'):  # Only validate new uploads
            if video.size > 50 * 1024 * 1024:  # 50MB
                raise forms.ValidationError("Video file too large ( > 50MB )")
            if not video.content_type.startswith('video/'):
                raise forms.ValidationError("File type not supported. Please upload a video.")
        return video

# --- Inline for Ratings ---
class RatingInline(admin.TabularInline):
    model = Rating
    extra = 0
    readonly_fields = ('user', 'rating', 'comment', 'created_at', 'is_verified_purchase')
    can_delete = False
    max_num = 0

# --- Category Admin ---
@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ['name', 'discount']
    search_fields = ['name']

# --- Subcategory Admin ---
@admin.register(Subcategory)
class SubcategoryAdmin(admin.ModelAdmin):
    list_display = ['name', 'category']
    search_fields = ['name']
    list_filter = ['category']

# --- Keyword Admin ---
@admin.register(Keyword)
class KeywordAdmin(admin.ModelAdmin):
    list_display = ['name']
    search_fields = ['name']

# --- ItemVariant Inline ---
class ItemVariantInline(admin.TabularInline):
    model = ItemVariant
    extra = 1

admin.site.register(ItemVariant)

# --- Affiliate Admin ---
@admin.register(Affiliate)
class AffiliateAdmin(admin.ModelAdmin):
    list_display = ['user', 'points']
    search_fields = ['user__username']

# --- AffiliateLink Admin ---
@admin.register(AffiliateLink)
class AffiliateLinkAdmin(admin.ModelAdmin):
    list_display = ['affiliate', 'item', 'unique_code', 'created_at']
    list_filter = ['affiliate']
    search_fields = ['affiliate__user__username', 'item__name', 'unique_code']

# --- Order Admin ---
@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ['id', 'user', 'delivery_status', 'payment_status', 'created_at']
    list_filter = ['delivery_status', 'payment_status', 'created_at']
    search_fields = ['user__username', 'id']
    readonly_fields = ['created_at']

# --- Item Admin ---
class ItemImageForm(forms.ModelForm):
    class Meta:
        model = ItemImage
        fields = '__all__'
    
    def clean_image(self):
        image = self.cleaned_data.get('image')
        if image and hasattr(image, 'content_type'):  # Only validate new uploads
            if image.size > 5 * 1024 * 1024:  # 5MB
                raise forms.ValidationError("Image file too large ( > 5MB )")
            if not image.content_type.startswith('image/'):
                raise forms.ValidationError("File type not supported. Please upload an image.")
        return image

class ItemImageInline(admin.TabularInline):
    model = ItemImage
    form = ItemImageForm
    extra = 1
    fields = ('image', 'order')
    ordering = ('order',)

@admin.register(Item)
class ItemAdmin(admin.ModelAdmin):
    form = ItemAdminForm
    list_display = ('id', 'name', 'sku', 'price', 'stock', 'average_rating', 'total_ratings', 'rating_stars', 'image_preview')
    search_fields = ('name', 'sku')
    list_filter = ('subcategory', 'stock', 'is_visible', 'special_item_status')
    ordering = ('id',)
    inlines = [ItemImageInline, RatingInline]
    readonly_fields = ('average_rating', 'total_ratings', 'rating_stars', 'video_preview')

    def average_rating(self, obj):
        avg = obj.ratings.aggregate(avg=Avg('rating'))['avg']
        return f"{avg:.1f}" if avg else "0.0"
    average_rating.short_description = 'Avg Rating'
    
    def total_ratings(self, obj):
        return obj.ratings.count()
    total_ratings.short_description = 'Total Reviews'
    
    def rating_stars(self, obj):
        avg = obj.ratings.aggregate(avg=Avg('rating'))['avg']
        if avg:
            stars = "★" * int(avg) + "☆" * (5 - int(avg))
            return f"{stars} ({avg:.1f})"
        return "☆☆☆☆☆ (0.0)"
    rating_stars.short_description = 'Rating Display'

    def image_preview(self, obj):
        """Show first image as preview in list view"""
        first_image = obj.images.first()
        if first_image and first_image.image:
            return f'<img src="{first_image.image.url}" style="max-height: 50px; max-width: 50px;" />'
        return "No Image"
    image_preview.short_description = 'Image Preview'
    image_preview.allow_tags = True

    def video_preview(self, obj):
        """Show video preview in detail view"""
        if obj.video:
            return f'''
            <video controls style="max-height: 200px; max-width: 300px;">
                <source src="{obj.video.url}" type="video/mp4">
                Your browser does not support the video tag.
            </video>
            <br><small>Video: {obj.video.name}</small>
            '''
        return "No Video"
    video_preview.short_description = 'Video Preview'
    video_preview.allow_tags = True

    def save_model(self, request, obj, form, change):
        """Override save to preserve existing video if not replaced"""
        if change:  # This is an update, not a new creation
            try:
                # Get the original object from database
                original_obj = Item.objects.get(pk=obj.pk)
                
                # Preserve existing video if new one is not uploaded
                if not obj.video and original_obj.video:
                    obj.video = original_obj.video
                    
            except Item.DoesNotExist:
                pass  # This is a new object
        
        super().save_model(request, obj, form, change)

    class Media:
        css = {
            'all': ('admin/css/custom_admin.css',)
        }
        js = ('admin/js/custom_admin.js',)

    fieldsets = (
        ('Basic Information', {
            'fields': ('name', 'sku', 'subcategory', 'price', 'discount', 'stock')
        }),
        ('Images & Media', {
            'fields': ('video', 'video_preview'),
            'description': 'Use the "Product Images" section below to add unlimited images. Video should be MP4, AVI, or MOV (max 50MB).'
        }),
        ('Product Images', {
            'fields': (),
            'description': 'Add unlimited product images using the inline form below. Images should be JPG, PNG, or GIF (max 5MB each).'
        }),
        ('Details', {
            'fields': ('specification', 'min_order_quantity', 'max_order_time')
        }),
        ('Rating Statistics', {
            'fields': ('average_rating', 'total_ratings', 'rating_stars'),
            'classes': ('collapse',)
        }),
        ('Advanced', {
            'fields': ('token', 'special_item_status', 'affiliate_token', 'is_visible'),
            'classes': ('collapse',)
        }),
        ('Dimensions', {
            'fields': ('length', 'breadth', 'height', 'weight'),
            'classes': ('collapse',)
        }),
    )

from django.contrib import admin
from .models import Customer, Address, CartItem, Item

class AddressInline(admin.TabularInline):
    model = Address
    extra = 1  # Allows adding extra addresses directly in the admin panel

class CartItemInline(admin.TabularInline):
    model = CartItem
    extra = 1  # Allows adding extra cart items directly in the admin panel

class CustomerAdmin(admin.ModelAdmin):
    list_display = ('name', 'email', 'phone', 'wallet_amount')
    search_fields = ('name', 'email', 'phone')
    list_filter = ('wallet_amount',)
    ordering = ('name',)
    inlines = [AddressInline, CartItemInline]  # Include addresses and cart items as inline forms

admin.site.register(Customer, CustomerAdmin)
from .models import PickupLocation, ReturnDetails

@admin.register(PickupLocation)
class PickupLocationAdmin(admin.ModelAdmin):
    list_display = ("name", "city", "state", "pin", "phone")

@admin.register(ReturnDetails)
class ReturnDetailsAdmin(admin.ModelAdmin):
    list_display = ("name", "city", "state", "pin", "phone")

from django.contrib import admin
from .models import AdvertisementNew
from django.contrib import admin
from django.core.exceptions import ValidationError
from django.contrib import messages
class AdvertisementAdmin1(admin.ModelAdmin):
    list_display = ('id', 'slideshow1', 'box1', 'big1', 'item_slideshow1')  # Fields to display in the list view
    list_filter = ('slideshow1', 'box1')  # Fields to enable filtering
    ordering = ('id',)  # Default ordering
    autocomplete_fields = ['item_slideshow1', 'item_box1', 'item_big1']  # Enable dropdown autocomplete for related fields
    readonly_fields = ('id',)  # Make the ID field read-only




    def save_model(self, request, obj, form, change):
        try:
            obj.save()
        except ValidationError as e:
            self.message_user(request, f"Error: {e.message}", level=messages.ERROR)

admin.site.register(AdvertisementNew, AdvertisementAdmin1)


class OrderDashboardItemInline(admin.TabularInline):
    model = OrderDashboardItem
    extra = 1

@admin.register(OrderDashboard)
class OrderDashboardAdmin(admin.ModelAdmin):
    list_display = ('name', 'mobile_number', 'total_amount', 'order_datetime', 'order_type', 'pay_id')
    list_filter = ('order_type', 'order_datetime')
    search_fields = ('name', 'mobile_number', 'pay_id')
    inlines = [OrderDashboardItemInline]

@admin.register(OrderDashboardItem)
class OrderDashboardItemAdmin(admin.ModelAdmin):
    list_display = ('order', 'name', 'price', 'sku', 'quantity')
    list_filter = ('order',)
    search_fields = ('name', 'sku')

from .models import SellerRequest, SellerProfile

@admin.register(SellerRequest)
class SellerRequestAdmin(admin.ModelAdmin):
    list_display = ('shop_name', 'user', 'contact_number', 'status', 'created_at')
    list_filter = ('status', 'created_at')
    search_fields = ('shop_name', 'user__email', 'contact_number')
    readonly_fields = ('created_at', 'updated_at')
    actions = ['approve_requests', 'reject_requests']

    def approve_requests(self, request, queryset):
        for seller_request in queryset:
            if seller_request.status == 'pending':
                # Generate random password
                password = get_random_string(10)
                seller_request.user.set_password(password)
                seller_request.user.save()

                # Create seller profile
                SellerProfile.objects.create(
                    user=seller_request.user,
                    seller_request=seller_request,
                    shop_name=seller_request.shop_name,
                    contact_number=seller_request.contact_number,
                    address=seller_request.address,
                    business_details=seller_request.business_details
                )

                # Update request status
                seller_request.status = 'approved'
                seller_request.save()

                # Send email with credentials
                send_mail(
                    'Your Seller Account is Approved',
                    f'Your seller account has been approved.\nUsername: {seller_request.user.email}\nPassword: {password}\nPlease change your password after login.',
                    'from@yourdomain.com',
                    [seller_request.user.email],
                    fail_silently=False,
                )
    approve_requests.short_description = "Approve selected seller requests"

    def reject_requests(self, request, queryset):
        for seller_request in queryset:
            if seller_request.status == 'pending':
                seller_request.status = 'rejected'
                seller_request.save()

                send_mail(
                    'Your Seller Account Request is Rejected',
                    'Your seller account request has been rejected. Please contact support for more information.',
                    'from@yourdomain.com',
                    [seller_request.user.email],
                    fail_silently=False,
                )
    reject_requests.short_description = "Reject selected seller requests"

@admin.register(SellerProfile)
class SellerProfileAdmin(admin.ModelAdmin):
    list_display = ('shop_name', 'user', 'contact_number', 'is_active', 'created_at')
    list_filter = ('is_active', 'created_at')
    search_fields = ('shop_name', 'user__email', 'contact_number')
    readonly_fields = ('created_at', 'updated_at')
    actions = ['deactivate_sellers', 'activate_sellers']

    def deactivate_sellers(self, request, queryset):
        queryset.update(is_active=False)
    deactivate_sellers.short_description = "Deactivate selected sellers"

    def activate_sellers(self, request, queryset):
        queryset.update(is_active=True)
    activate_sellers.short_description = "Activate selected sellers"
