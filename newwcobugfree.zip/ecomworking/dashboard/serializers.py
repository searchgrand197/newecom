from rest_framework import serializers
from django.contrib.auth.models import User
from django.utils.crypto import get_random_string
from .models import Category, Subcategory, Item, Affiliate, AffiliateLink, Order, Keyword, SellerRequest, SellerProfile, ItemVariant, OrderDashboardItem, OrderDashboard, Address
from django.shortcuts import get_object_or_404
from rating.serializers import RatingSerializer
from rating.models import Rating
from django.db.models import Avg

class AddressSerializer(serializers.ModelSerializer):
    class Meta:
        model = Address
        fields = '__all__'

class UserSerializer(serializers.ModelSerializer):
    addresses = AddressSerializer(many=True, read_only=True)  # Nested Address list

    class Meta:
        model = User
        fields = '__all__'

class SellerProfileSerializer(serializers.ModelSerializer):
    user = UserSerializer(read_only=True)
    seller_id = serializers.CharField(read_only=True)
    seller_code = serializers.CharField(read_only=True)
    shop_name = serializers.CharField(read_only=True)

    class Meta:
        model = SellerProfile
        fields = ['id', 'user', 'seller_id', 'seller_code', 'shop_name', 'contact_number', 'address', 'business_details', 'is_active', 'created_at']

class ItemVariantSerializer(serializers.ModelSerializer):
    class Meta:
        model = ItemVariant
        fields = ['id', 'color', 'size', 'price', 'stock']
class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = ['id','name', 'image','details','discount']

class SubCategorySerializer(serializers.ModelSerializer):
    category = serializers.SlugRelatedField(queryset=Category.objects.all(), slug_field='name')
    category_id = serializers.PrimaryKeyRelatedField(queryset=Category.objects.all())  # Use PrimaryKeyRelatedField for category ID

    class Meta:
        model = Subcategory
        fields = ['category_id','id','name', 'category','details','image', 'discount']

class KeywordSerializer(serializers.ModelSerializer):
    class Meta:
        model = Keyword
        fields = ['id', 'name']

    def create(self, validated_data):
        keyword, created = Keyword.objects.get_or_create(**validated_data)
        return keyword
class ItemSerializer(serializers.ModelSerializer):
    subcategory = serializers.SlugRelatedField(queryset=Subcategory.objects.all(), slug_field='name')
    variants = ItemVariantSerializer(many=True, read_only=True)
    category_id = serializers.IntegerField(source='subcategory.category.id', read_only=True)
    subcategory_id = serializers.IntegerField(source='subcategory.id', read_only=True)
    category_name = serializers.SerializerMethodField()
    subcategory_name = serializers.SerializerMethodField()
    keywords = KeywordSerializer(many=True, read_only=True)
    keywords_input = serializers.ListField(
        child=serializers.CharField(max_length=255),
        write_only=True,
        required=False
    )
    variants_input = ItemVariantSerializer(many=True, write_only=True, required=False)
    images = serializers.SerializerMethodField()
    seller = SellerProfileSerializer(read_only=True)
    seller_code = serializers.CharField(read_only=True)
    seller_identifier = serializers.CharField(read_only=True)
    # Keep old image fields for backward compatibility but mark as deprecated
    image1_url = serializers.SerializerMethodField()
    image2_url = serializers.SerializerMethodField()
    image3_url = serializers.SerializerMethodField()
    average_rating = serializers.SerializerMethodField()
    total_ratings = serializers.SerializerMethodField()

    class Meta:
        model = Item
        fields = [
            'id', 'name', 'image1', 'image2', 'image3', 'image1_url', 'image2_url', 'image3_url',
            'video', 'subcategory', 'sku', 'stock', 'price', 'discount', 'specification',
            'token', 'special_item_status', 'affiliate_token', 'length', 'breadth', 'height',
            'weight', 'seller', 'seller_code', 'variants', 'variants_input', 'keywords',
            'keywords_input', 'images', 'category_id', 'subcategory_id', 'category_name', 'subcategory_name', 'seller_identifier',
            'min_order_quantity', 'max_order_time', 'average_rating', 'total_ratings'
        ]

    def get_category_name(self, obj):
        if obj.subcategory and obj.subcategory.category:
            return obj.subcategory.category.name
        return None

    def get_subcategory_name(self, obj):
        if obj.subcategory:
            return obj.subcategory.name
        return None

    def get_image1_url(self, obj):
        request = self.context.get('request')
        if obj.image1:
            return request.build_absolute_uri(obj.image1.url) if request else obj.image1.url
        return None

    def get_image2_url(self, obj):
        request = self.context.get('request')
        if obj.image2:
            return request.build_absolute_uri(obj.image2.url) if request else obj.image2.url
        return None

    def get_image3_url(self, obj):
        request = self.context.get('request')
        if obj.image3:
            return request.build_absolute_uri(obj.image3.url) if request else obj.image3.url
        return None

    def get_images(self, obj):
        request = self.context.get('request')
        image_urls = []
        
        # First, try to get images from the new ItemImage model
        item_images = obj.images.all().order_by('order')
        if item_images.exists():
            for item_image in item_images:
                if item_image.image:
                    image_urls.append(self.build_absolute_image_url(item_image.image.url))
        else:
            # Fallback to old image fields for backward compatibility
            for img in [obj.image1, obj.image2, obj.image3]:
                if img:
                    image_urls.append(self.build_absolute_image_url(img.url))
        
        return image_urls

    def build_absolute_image_url(self, image_url):
        request = self.context.get('request')
        if request:
            return request.build_absolute_uri(image_url)
        return image_url

    def get_average_rating(self, obj):
        avg_rating = Rating.objects.filter(item=obj).aggregate(avg=Avg('rating'))['avg']
        return round(avg_rating, 1) if avg_rating else 0

    def get_total_ratings(self, obj):
        return Rating.objects.filter(item=obj).count()

    def to_representation(self, instance):
        data = super().to_representation(instance)
        # Remove the binary image data from the response
        data.pop('image1', None)
        data.pop('image2', None)
        data.pop('image3', None)
        
        # Format video URL if it exists
        if instance.video:
            request = self.context.get('request')
            if request:
                data['video'] = request.build_absolute_uri(instance.video.url)
            else:
                data['video'] = instance.video.url
        else:
            data['video'] = None
            
        return data

    def update(self, instance, validated_data):
        # Handle image updates
        if 'image1' in validated_data:
            instance.image1 = validated_data.pop('image1')
        if 'image2' in validated_data:
            instance.image2 = validated_data.pop('image2')
        if 'image3' in validated_data:
            instance.image3 = validated_data.pop('image3')

        # Handle keywords
        keywords_data = validated_data.pop('keywords_input', None)
        if keywords_data is not None:
            instance.keywords.clear()
            for keyword_name in keywords_data:
                keyword, created = Keyword.objects.get_or_create(name=keyword_name)
                instance.keywords.add(keyword)

        # Handle variants
        variants_data = validated_data.pop('variants_input', None)
        if variants_data is not None:
            instance.variants.all().delete()
            for variant_data in variants_data:
                ItemVariant.objects.create(item=instance, **variant_data)

        # Update other fields
        for attr, value in validated_data.items():
            setattr(instance, attr, value)

        instance.save()
        return instance


class AffiliateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Affiliate
        fields = '__all__'

from django.shortcuts import get_object_or_404
from rest_framework import serializers
from .models import AffiliateLink, Affiliate, Item
from django.utils.crypto import get_random_string

class AffiliateLinkSerializer(serializers.ModelSerializer):
    link = serializers.SerializerMethodField(read_only=True)
    status = serializers.SerializerMethodField(read_only=True)  # Add status as a read-only field
    affiliate_username = serializers.CharField(write_only=True, required=True)

    class Meta:
        model = AffiliateLink
        fields = ['id', 'affiliate_username', 'item', 'affiliate_token', 'unique_code', 'created_at', 'link', 'status']
        read_only_fields = ['unique_code', 'created_at']

    def get_link(self, obj):
        return obj.generate_link()

    def get_status(self, obj):
        # This will be set in the create method, so we return it later
        return self.context.get('status', 'unknown')

    def create(self, validated_data):
        # Extract affiliate_username from validated_data
        affiliate_username = validated_data.pop('affiliate_username')

        # Get the Affiliate object associated with the given username
        affiliate = get_object_or_404(Affiliate, user=affiliate_username)

        # Get the item from the validated data
        item = validated_data.get('item')

        # Check if an affiliate link already exists for this affiliate and item
        existing_link = AffiliateLink.objects.filter(affiliate=affiliate, item=item).first()

        if existing_link:
            # Return the existing link's data with status "already generated"
            self.context['status'] = 'already generated'
            return existing_link  # Return the existing link object

        # Assign the Affiliate object to validated_data
        validated_data['affiliate'] = affiliate

        # Automatically generate a unique_code if not present
        if 'unique_code' not in validated_data:
            validated_data['unique_code'] = get_random_string(length=10)

        # Create the new AffiliateLink object
        new_link = super().create(validated_data)

        # Set status in context for use in the response
        self.context['status'] = 'newly generated'
        return new_link  # Return the newly created link object




class SalesByCategorySerializer(serializers.ModelSerializer):
    total_sales = serializers.DecimalField(max_digits=10, decimal_places=2)

    class Meta:
        model = Category
        fields = ['name', 'total_sales']

class SalesByRegionSerializer(serializers.Serializer):
    region = serializers.CharField()
    total_sales = serializers.DecimalField(max_digits=10, decimal_places=2)

class TopSellingProductSerializer(serializers.ModelSerializer):
    sales_count = serializers.IntegerField()
    images = serializers.SerializerMethodField()  # Use SerializerMethodField to handle custom logic
    subcategory_id = serializers.IntegerField(source='subcategory.id', read_only=True)
    category_id = serializers.IntegerField(source='subcategory.category.id', read_only=True)
    keywords = KeywordSerializer(many=True, read_only=True)
    variants = ItemVariantSerializer(many=True, read_only=True)
    class Meta:
        model = Item
        fields = ['subcategory_id', 'category_id','id', 'name', 'sku', 'sales_count', 'images','price','discount', 'specification', 'token', 'special_item_status',
                  'affiliate_token', 'last_modified_by', 'keywords',  'variants']
    def get_subcategory_id(self, obj):
        return obj.subcategory.id if obj.subcategory else None

    def get_category_id(self, obj):
        return obj.subcategory.category.id if obj.subcategory and obj.subcategory.category else None
    def get_images(self, obj):
        # Collect image URLs into an array and build absolute URI
        request = self.context.get('request')
        image_urls = []
        
        # First, try to get images from the new ItemImage model
        item_images = obj.images.all().order_by('order')
        if item_images.exists():
            for item_image in item_images:
                if item_image.image:
                    image_urls.append(self.build_absolute_image_url(item_image.image.url))
        else:
            # Fallback to old image fields for backward compatibility
            for img in [obj.image1, obj.image2, obj.image3]:
                if img:
                    image_urls.append(self.build_absolute_image_url(img.url))
        
        return image_urls

    def build_absolute_image_url(self, image_url):
        request = self.context.get('request')
        if request:
            return request.build_absolute_uri(image_url)
        return image_url

    def to_representation(self, instance):
        data = super().to_representation(instance)
        
        # Format video URL if it exists
        if instance.video:
            request = self.context.get('request')
            if request:
                data['video'] = request.build_absolute_uri(instance.video.url)
            else:
                data['video'] = instance.video.url
        else:
            data['video'] = None
            
        return data

class MonthWiseSalesSerializer(serializers.Serializer):
    month = serializers.DateField()
    total_sales = serializers.DecimalField(max_digits=10, decimal_places=2)

class YearSalesSerializer(serializers.Serializer):
    year = serializers.IntegerField()  # Year should be an integer
    total_sales = serializers.DecimalField(max_digits=10, decimal_places=2)

class AdminInsightsSerializer(serializers.Serializer):
    total_sales_today = serializers.DecimalField(max_digits=10, decimal_places=2)
    sales_by_category = serializers.ListField(child=SalesByCategorySerializer())
    sales_by_category_count = serializers.IntegerField()

    sales_by_region = serializers.ListField(child=SalesByRegionSerializer())
    sales_by_region_count = serializers.IntegerField()

    top_selling_products = serializers.ListField(child=TopSellingProductSerializer())
    top_selling_products_count = serializers.IntegerField()

    dispatched_orders = serializers.ListField(child=serializers.CharField())
    dispatched_orders_count = serializers.IntegerField()

    pending_orders = serializers.ListField(child=serializers.CharField())
    pending_orders_count = serializers.IntegerField()

    cancelled_orders = serializers.ListField(child=serializers.CharField())
    cancelled_orders_count = serializers.IntegerField()

    low_stock_alerts = serializers.ListField(child=serializers.CharField())
    low_stock_alerts_count = serializers.IntegerField()

    month_wise_sales = serializers.ListField(child=MonthWiseSalesSerializer())
    month_wise_sales_count = serializers.IntegerField()

    year_sales = serializers.ListField(child=YearSalesSerializer())
    year_sales_count = serializers.IntegerField()
class SubcategorySerializerto(serializers.ModelSerializer):
    class Meta:
        model = Subcategory
        fields = ['id','name', 'image']

class CategorySerializerto(serializers.ModelSerializer):
    subcategories = SubcategorySerializerto(many=True,source='subcategory')

    class Meta:
        model = Category
        fields = ['id','name', 'image', 'subcategories']




class ItemSearch(serializers.ModelSerializer):
    class Meta:
        model = Item
        fields = ['name', 'price', 'image1']

    def get_image(self, obj):
        request = self.context.get('request')
        if obj.image1:
            return request.build_absolute_uri(obj.image1.url)
        return None


from rest_framework import serializers
from .models import Advertisement, AdvertisementImage, Item

# Serializer for AdvertisementImage
class AdvertisementImageSerializer(serializers.ModelSerializer):
    class Meta:
        model = AdvertisementImage
        fields = ['image']  # You can add more fields like 'id' or 'item' if needed

# Serializer for Item (handpicked items)
class ItemSerializer1(serializers.ModelSerializer):
    category_id = serializers.IntegerField(source='subcategory.category.id', read_only=True)
    subcategory_id = serializers.IntegerField(source='subcategory.id', read_only=True)
    images = serializers.SerializerMethodField()
    keywords = KeywordSerializer(many=True, read_only=True)
    variants = ItemVariantSerializer(many=True, read_only=True)
    average_rating = serializers.SerializerMethodField()
    total_ratings = serializers.SerializerMethodField()

    class Meta:
        model = Item
        fields = ['category_id','subcategory_id','id', 'name','images', 'price','price', 'discount', 'specification', 'token', 'special_item_status',
                  'affiliate_token', 'last_modified_by', 'keywords',  'variants', 'average_rating', 'total_ratings']  # Adjust fields as needed for your use case
    def get_images(self, obj):
        # Collect image URLs into an array and build absolute URI
        request = self.context.get('request')
        image_urls = []
        
        # First, try to get images from the new ItemImage model
        item_images = obj.images.all().order_by('order')
        if item_images.exists():
            for item_image in item_images:
                if item_image.image:
                    if request:
                        image_urls.append(request.build_absolute_uri(item_image.image.url))
                    else:
                        image_urls.append(item_image.image.url)
        else:
            # Fallback to old image fields for backward compatibility
            for img in [obj.image1, obj.image2, obj.image3]:
                if img:
                    if request:
                        image_urls.append(request.build_absolute_uri(img.url))
                    else:
                        image_urls.append(img.url)
        
        return image_urls

    def get_average_rating(self, obj):
        avg_rating = Rating.objects.filter(item=obj).aggregate(avg=Avg('rating'))['avg']
        return round(avg_rating, 1) if avg_rating else 0

    def get_total_ratings(self, obj):
        return Rating.objects.filter(item=obj).count()

    def to_representation(self, instance):
        data = super().to_representation(instance)
        
        # Format video URL if it exists
        if instance.video:
            request = self.context.get('request')
            if request:
                data['video'] = request.build_absolute_uri(instance.video.url)
            else:
                data['video'] = instance.video.url
        else:
            data['video'] = None
            
        return data

# Serializer for Advertisement
class AdvertisementSerializer(serializers.ModelSerializer):
    # Nest the AdvertisementImageSerializer to include all images
    landscape_images = AdvertisementImageSerializer(many=True, read_only=True)

    # Nest the ItemSerializer for handpicked items
    handpicked_items = ItemSerializer1(many=True, read_only=True)

    class Meta:
        model = Advertisement
        fields = ['id', 'sliding_text', 'landscape_images', 'handpicked_items']

from rest_framework import serializers
from .models import User, Address

class AddressSerializer(serializers.ModelSerializer):
    class Meta:
        model = Address
        fields = '__all__'

class UserSerializer(serializers.ModelSerializer):
    addresses = AddressSerializer(many=True, read_only=True)  # Nested Address list

    class Meta:
        model = User
        fields = '__all__'

from rest_framework import serializers
from .models import AffiliateUser



from rest_framework import serializers
from django.core.signing import TimestampSigner
from django.urls import reverse
from .models import AffiliateUser

signer = TimestampSigner()

class AffiliateUserSerializer(serializers.ModelSerializer):
    approve_link = serializers.SerializerMethodField()
    reject_link = serializers.SerializerMethodField()
    block_link = serializers.SerializerMethodField()

    class Meta:
        model = AffiliateUser
        fields = ['uid', 'name', 'mobile','email', 'age', 'address', 'document_type', 'document_upload', 'status', 'approve_link', 'reject_link', 'block_link']

    def get_approve_link(self, obj):
        request = self.context.get('request')
        if request:
            approve_token = signer.sign(f'{obj.uid}:approved')
            return request.build_absolute_uri(reverse('secure_change_affiliate_status', args=[approve_token]))
        return None

    def get_reject_link(self, obj):
        request = self.context.get('request')
        if request:
            reject_token = signer.sign(f'{obj.uid}:rejected')
            return request.build_absolute_uri(reverse('secure_change_affiliate_status', args=[reject_token]))
        return None

    def get_block_link(self, obj):
        request = self.context.get('request')
        if request:
            block_token = signer.sign(f'{obj.uid}:blocked')
            return request.build_absolute_uri(reverse('secure_change_affiliate_status', args=[block_token]))
        return None

from rest_framework import serializers

class AffiliateLoginSerializer(serializers.Serializer):
    username = serializers.CharField(max_length=50)
    password = serializers.CharField(write_only=True)

from rest_framework import serializers
from .models import Comment, Reply

class CommentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Comment
        fields = ['id', 'item', 'user', 'content', 'created_at']

class ReplySerializer(serializers.ModelSerializer):
    class Meta:
        model = Reply
        fields = ['id', 'comment', 'user', 'content', 'created_at']

# from rest_framework import serializers
# from .models import AffiliateLink
#
# from rest_framework import serializers
# from django.shortcuts import get_object_or_404
# from .models import AffiliateLink, Affiliate
#
# class AffiliateLinkSerializer2(serializers.ModelSerializer):
#     link = serializers.SerializerMethodField(read_only=True)
#     affiliate_username = serializers.CharField(write_only=True, required=True)  # Accept username instead of id
#
#     class Meta:
#         model = AffiliateLink
#         fields = ['id', 'affiliate_username', 'item', 'affiliate_token', 'unique_code', 'created_at', 'link']
#         read_only_fields = ['unique_code', 'created_at']
#
#     def get_link(self, obj):
#         return obj.generate_link()
#
#     def create(self, validated_data):
#         # Extract affiliate_username from validated_data and replace it with the actual Affiliate object
#         affiliate_username = validated_data.pop('affiliate_username')
#
#         # Find the affiliate using the provided username
#         affiliate = get_object_or_404(Affiliate, user__username=affiliate_username)
#
#         # Assign the Affiliate object to validated_data
#         validated_data['affiliate'] = affiliate
#
#         # The unique_code will be automatically generated if not present
#         if 'unique_code' not in validated_data:
#             validated_data['unique_code'] = get_random_string(length=10)
#
#         # Check if a link with this affiliate and item already exists
#         affiliate_link, created = AffiliateLink.objects.get_or_create(
#             affiliate=affiliate,
#             item=validated_data['item'],
#             defaults={'affiliate_token': validated_data.get('affiliate_token')}
#         )
#
#         return affiliate_link  # Return the existing or newly created link
#
from rest_framework import serializers
from .models import Order, OrderItem

class OrderItemSerializer(serializers.ModelSerializer):
    rating = serializers.SerializerMethodField()

    class Meta:
        model = OrderDashboardItem
        fields = ['id', 'name', 'price', 'quantity', 'image', 'rating']

    def get_rating(self, obj):
        from rating.models import Rating
        user = self.context.get('request').user if self.context.get('request') else None
        if user and user.is_authenticated:
            # Use obj.item.id if item is a FK, or get item by SKU if only SKU is available
            item_id = getattr(obj, 'item_id', None)
            if not item_id and hasattr(obj, 'item') and obj.item:
                item_id = obj.item.id
            if not item_id and hasattr(obj, 'sku'):
                from dashboard.models import Item
                try:
                    item_id = Item.objects.get(sku=obj.sku).id
                except Item.DoesNotExist:
                    item_id = None
            if item_id:
             rating = Rating.objects.filter(
                    item_id=item_id,
                user=user
            ).first()
            if rating:
                return {
                    'rating': rating.rating,
                    'comment': rating.comment,
                    'created_at': rating.created_at
                }
        return None

class OrderSerializer(serializers.ModelSerializer):
    items = OrderItemSerializer(many=True, read_only=True)
    customer = UserSerializer(read_only=True)
    order_date = serializers.DateTimeField(source='created_at', format="%Y-%m-%d %H:%M:%S", read_only=True)

    class Meta:
        model = OrderDashboard
        fields = ['id', 'customer', 'items', 'order_id', 'address', 'region', 'order_date', 'delivery_status', 'payment_status']

    def create(self, validated_data):
        # Extract order items data
        order_items_data = validated_data.pop('order_items')

        # Create the order without order items
        order = OrderDashboard.objects.create(**validated_data)

        # Create order items
        for order_item_data in order_items_data:
            OrderDashboardItem.objects.create(order=order, **order_item_data)

        return order

    def update(self, instance, validated_data):
        # Extract order items data
        order_items_data = validated_data.pop('order_items', None)

        # Update the order fields
        instance.order_id = validated_data.get('order_id', instance.order_id)
        instance.address = validated_data.get('address', instance.address)
        instance.delivery_status = validated_data.get('delivery_status', instance.delivery_status)
        instance.payment_status = validated_data.get('payment_status', instance.payment_status)
        instance.region = validated_data.get('region', instance.region)
        instance.save()

        # Update or create order items
        if order_items_data is not None:
            # Clear existing order items
            instance.order_items.all().delete()
            for order_item_data in order_items_data:
                OrderDashboardItem.objects.create(order=instance, **order_item_data)

        return instance

from rest_framework import serializers
from .models import Customer, Address, CartItem, Item

class AddressSerializer(serializers.ModelSerializer):
    class Meta:
        model = Address
        fields = ['address_line1', 'city', 'state', 'postal_code', 'country']

class CartItemSerializer(serializers.ModelSerializer):
    item_name = serializers.ReadOnlyField(source='item.name')  # To display item name in the API

    class Meta:
        model = CartItem
        fields = ['item', 'item_name', 'quantity']
class CartItemSerializer2(serializers.ModelSerializer):
    item = ItemSerializer()  # To display item name in the API

    class Meta:
        model = CartItem
        fields = ['item','quantity']


class CustomerSerializer(serializers.ModelSerializer):
    addresses = AddressSerializer(many=True)  # Nested address serializer
    cart_items = CartItemSerializer(many=True)  # Nested cart item serializer

    class Meta:
        model = Customer
        fields = ['id','user','name', 'email', 'phone', 'wallet_amount', 'addresses', 'cart_items']

    def create(self, validated_data):
        addresses_data = validated_data.pop('addresses')
        cart_items_data = validated_data.pop('cart_items')
        customer = Customer.objects.create(**validated_data)

        # Create addresses
        for address_data in addresses_data:
            Address.objects.create(customer=customer, **address_data)

        # Create cart items
        for cart_item_data in cart_items_data:
            CartItem.objects.create(customer=customer, **cart_item_data)

        return customer
class CustomerSerializer(serializers.ModelSerializer):
    addresses = AddressSerializer(many=True)  # Nested address serializer
    cart_items = CartItemSerializer(many=True)  # Nested cart item serializer
    cart_items_detail = CartItemSerializer2(source='cart_items', many=True, read_only=True)  # For GET

    class Meta:
        model = Customer
        fields = ['id', 'user', 'name', 'email', 'phone', 'wallet_amount', 'addresses', 'cart_items','cart_items_detail']
        extra_kwargs = {
            'cart_items_detail': {'read_only': True},  # Return only in GET
        }
    def create(self, validated_data):
        addresses_data = validated_data.pop('addresses')
        cart_items_data = validated_data.pop('cart_items')
        customer = Customer.objects.create(**validated_data)

        # Create addresses
        for address_data in addresses_data:
            Address.objects.create(customer=customer, **address_data)

        # Create cart items
        for cart_item_data in cart_items_data:
            CartItem.objects.create(customer=customer, **cart_item_data)

        return customer

    def update(self, instance, validated_data):
        addresses_data = validated_data.pop('addresses', None)
        cart_items_data = validated_data.pop('cart_items', None)

        # Update customer fields
        instance.name = validated_data.get('name', instance.name)
        instance.email = validated_data.get('email', instance.email)
        instance.phone = validated_data.get('phone', instance.phone)
        instance.wallet_amount = validated_data.get('wallet_amount', instance.wallet_amount)
        instance.save()

        # Update or create addresses
        if addresses_data is not None:
            # Delete old addresses that are not in the new data
            Address.objects.filter(customer=instance).exclude(address_line1__in=[a['address_line1'] for a in addresses_data]).delete()

            # Create or update the addresses
            for address_data in addresses_data:
                Address.objects.update_or_create(
                    customer=instance,
                    address_line1=address_data['address_line1'],
                    defaults=address_data
                )

        # Update or create cart items
        if cart_items_data is not None:
            # Delete old cart items that are not in the new data
            CartItem.objects.filter(customer=instance).exclude(item__in=[c['item'] for c in cart_items_data]).delete()

            # Create or update the cart items
            for cart_item_data in cart_items_data:
                CartItem.objects.update_or_create(
                    customer=instance,
                    item=cart_item_data['item'],
                    defaults={'quantity': cart_item_data['quantity']}
                )

        return instance

from django.contrib.auth.models import User
from rest_framework import serializers
from .models import Customer

class CustomerUserSerializer(serializers.ModelSerializer):
    username = serializers.CharField(source='user.username')
    password = serializers.CharField(write_only=True)

    class Meta:
        model = Customer
        fields = ['id', 'username', 'password']

    def create(self, validated_data):
        # Extract username and password for user creation
        user_data = validated_data.pop('user')
        username = user_data.get('username')
        password = validated_data.get('password')

        # Create the user
        user = User.objects.create_user(username=username, password=password)

        # Create customer linked to the user
        customer = Customer.objects.create(user=user, **validated_data)
        return customer

from rest_framework import serializers
from .models import AdvertisementNew

# class AdvertisementSerializer1(serializers.ModelSerializer):
#     class Meta:
#         model = AdvertisementNew
#         fields = '__all__'
from rest_framework import serializers
from .models import AdvertisementNew, Item

class ItemDetailsSerializer(serializers.ModelSerializer):
    subcategory_id = serializers.IntegerField(source='subcategory.id', read_only=True)
    category_id = serializers.IntegerField(source='subcategory.category.id', read_only=True)

    class Meta:
        model = Item
        fields = ['id', 'name', 'subcategory_id', 'category_id']

class AdvertisementSerializer1(serializers.ModelSerializer):
    item_slideshow1 = ItemDetailsSerializer(read_only=True)
    item_slideshow2 = ItemDetailsSerializer(read_only=True)
    item_slideshow3 = ItemDetailsSerializer(read_only=True)
    item_box1 = ItemDetailsSerializer(read_only=True)
    item_box2 = ItemDetailsSerializer(read_only=True)
    item_box3 = ItemDetailsSerializer(read_only=True)
    item_box4 = ItemDetailsSerializer(read_only=True)
    item_box5 = ItemDetailsSerializer(read_only=True)
    item_video1 = ItemDetailsSerializer(read_only=True)
    item_video2 = ItemDetailsSerializer(read_only=True)
    item_video3 = ItemDetailsSerializer(read_only=True)
    item_video4 = ItemDetailsSerializer(read_only=True)
    item_video5 = ItemDetailsSerializer(read_only=True)
    item_video6 = ItemDetailsSerializer(read_only=True)
    item_ibox1 = ItemDetailsSerializer(read_only=True)
    item_ibox2 = ItemDetailsSerializer(read_only=True)
    item_ibox3 = ItemDetailsSerializer(read_only=True)
    item_ibox4 = ItemDetailsSerializer(read_only=True)
    item_big1 = ItemDetailsSerializer(read_only=True)

    class Meta:
        model = AdvertisementNew
        fields = [
            'id', 'slideshow1', 'slideshow2', 'slideshow3',
            'box1', 'box2', 'box3', 'box4', 'box5',
            'video1', 'video2', 'video3', 'video4', 'video5', 'video6',
            'ibox1', 'ibox2', 'ibox3', 'ibox4', 'big1',
            'item_slideshow1', 'item_slideshow2', 'item_slideshow3',
            'item_box1', 'item_box2', 'item_box3', 'item_box4', 'item_box5',
            'item_video1', 'item_video2', 'item_video3', 'item_video4', 'item_video5', 'item_video6',
            'item_ibox1', 'item_ibox2', 'item_ibox3', 'item_ibox4',
            'item_big1'
        ]

class OrderDashboardItemSerializer(serializers.ModelSerializer):
    seller_info = serializers.SerializerMethodField()
    rating = serializers.SerializerMethodField()
    item_id = serializers.SerializerMethodField()
    
    class Meta:
        model = OrderDashboardItem
        fields = ['id', 'name', 'price', 'sku', 'quantity', 'seller_info', 'rating', 'item_id']
    
    def get_seller_info(self, obj):
        try:
            item = Item.objects.get(sku=obj.sku)
            if item.seller:
                return {
                    'seller_id': item.seller.seller_id,
                    'seller_code': item.seller.seller_code,
                    'shop_name': item.seller.shop_name,
                    'type': 'seller'
                }
            return {
                'seller_id': 'admin',
                'seller_code': 'admin',
                'shop_name': 'Admin',
                'type': 'admin'
            }
        except Item.DoesNotExist:
            return None

    def get_rating(self, obj):
        from rating.models import Rating
        user = self.context.get('request').user if self.context.get('request') else None
        if user and user.is_authenticated:
            # Use obj.item.id if item is a FK, or get item by SKU if only SKU is available
            item_id = getattr(obj, 'item_id', None)
            if not item_id and hasattr(obj, 'item') and obj.item:
                item_id = obj.item.id
            if not item_id and hasattr(obj, 'sku'):
                from dashboard.models import Item
                try:
                    item_id = Item.objects.get(sku=obj.sku).id
                except Item.DoesNotExist:
                    item_id = None
            if item_id:
                rating = Rating.objects.filter(
                    item_id=item_id,
                user=user
            ).first()
            if rating:
                return {
                    'rating': rating.rating,
                    'comment': rating.comment,
                    'created_at': rating.created_at
                }
        return None

    def get_item_id(self, obj):
        from dashboard.models import Item
        try:
            return Item.objects.get(sku=obj.sku).id
        except Item.DoesNotExist:
            return None

class OrderDashboardSerializer(serializers.ModelSerializer):
    items = OrderDashboardItemSerializer(many=True)
    order_by = serializers.PrimaryKeyRelatedField(read_only=True)
    seller_orders = serializers.SerializerMethodField()

    class Meta:
        model = OrderDashboard
        fields = ['id', 'name', 'mobile_number', 'address', 'items', 
                 'total_amount', 'order_datetime', 'order_type', 'pay_id', 'pcode', 'status', 'order_by', 'seller_orders']

    def get_seller_orders(self, obj):
        # Group items by seller
        seller_items = {}
        for item in obj.items.all():
            try:
                item_obj = Item.objects.get(sku=item.sku)
                seller_id = item_obj.seller.seller_id if item_obj.seller else 'admin'
                if seller_id not in seller_items:
                    seller_items[seller_id] = {
                        'seller_id': seller_id,
                        'seller_code': item_obj.seller.seller_code if item_obj.seller else 'admin',
                        'shop_name': item_obj.seller.shop_name if item_obj.seller else 'Admin',
                        'items': []
                    }
                seller_items[seller_id]['items'].append({
                    'name': item.name,
                    'price': item.price,
                    'quantity': item.quantity,
                    'sku': item.sku
                })
            except Item.DoesNotExist:
                continue
        return list(seller_items.values())

    def create(self, validated_data):
        items_data = validated_data.pop('items')
        order = OrderDashboard.objects.create(**validated_data)
        for item_data in items_data:
            OrderDashboardItem.objects.create(order=order, **item_data)
        
        return order

class SellerRequestSerializer(serializers.ModelSerializer):
    email = serializers.EmailField(write_only=True, required=True)
    password = serializers.CharField(write_only=True, required=True)

    class Meta:
        model = SellerRequest
        fields = ['id', 'email', 'password', 'shop_name', 'contact_number', 'address', 'business_details', 'status', 'created_at', 'updated_at']
        read_only_fields = ['id', 'status', 'created_at', 'updated_at']

    def create(self, validated_data):
        try:
            # Extract user data
            email = validated_data.pop('email')
            password = validated_data.pop('password')

            # Create or get user
            user, created = User.objects.get_or_create(
                email=email,
                defaults={
                    'username': email,
                    'is_active': True
                }
            )

            # Set password if user was just created
            if created:
                user.set_password(password)
                user.save()

            # Create seller request
            seller_request = SellerRequest.objects.create(
                user=user,
                **validated_data
            )

            return seller_request

        except Exception as e:
            raise serializers.ValidationError(f"Error creating seller request: {str(e)}")
