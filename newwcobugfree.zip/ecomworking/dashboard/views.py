from .models import Category, Subcategory, Item, Order, OrderDashboard, OrderDashboardItem, Affiliate, AffiliateLink, RecentlyViewed, ItemImage
from .serializers import CategorySerializer, SubCategorySerializer, ItemSerializer
from rest_framework.permissions import IsAdminUser
from rest_framework import viewsets
from rest_framework.decorators import action
from .models import Affiliate, AffiliateLink, Item, Order , OrderDashboard, OrderDashboardItem
from .serializers import AffiliateLinkSerializer, OrderSerializer,AffiliateLoginSerializer, OrderDashboardItemSerializer, OrderDashboardSerializer
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.shortcuts import get_object_or_404
from .models import AffiliateLink
from .serializers import ItemSerializer
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.contrib.auth import authenticate, login
from django.middleware.csrf import get_token
from rest_framework.permissions import AllowAny
from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator
from django.views.decorators.csrf import csrf_exempt
from rest_framework import viewsets,mixins
from rest_framework.response import Response
from rest_framework.permissions import IsAdminUser
from rest_framework import status
from django.db.models import Q
from fuzzywuzzy import process
from rest_framework.decorators import api_view
from django.db import transaction
from django.utils import timezone

from .models import Category
from .serializers import CategorySerializer
from rest_framework.generics import ListAPIView
from rest_framework.response import Response
from rest_framework import status
from .models import Item, Keyword,Affiliate
from .serializers import ItemSerializer,ItemSearch
from rest_framework.generics import CreateAPIView
from .serializers import KeywordSerializer,CategorySerializerto
from rest_framework.pagination import PageNumberPagination
from django.views.generic import TemplateView
from django.conf import settings
from rest_framework.decorators import api_view, permission_classes, action
from rest_framework.permissions import AllowAny, IsAuthenticated, IsAdminUser
from rest_framework import viewsets, status, mixins
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.generics import ListAPIView, CreateAPIView
from rest_framework.pagination import PageNumberPagination
from django.db import models, transaction
from django.shortcuts import render, get_object_or_404
from django.core.exceptions import PermissionDenied
from django.views.generic import TemplateView
from django.conf import settings
from fuzzywuzzy import process
from django.http import Http404
class ItemPagination(PageNumberPagination):
    page_size = 30  # Number of items per page
class StandardResultsSetPagination(PageNumberPagination):
    page_size = 10  # You can adjust this value


class AuthenticatedCheckView(APIView):
    # Disable authentication and permission checks for this view
    authentication_classes = []
    permission_classes = [AllowAny]

    def post(self, request):
        username = request.data.get('username')
        password = request.data.get('password')

        user = authenticate(username=username, password=password)

        if user is not None:
            login(request, user)  # Log the user in to create a session
            csrf_token = get_token(request)  # Get CSRF token
            sessionid = request.session.session_key  # Get session ID
            return Response({
                "status": "success",
                "statuscode":status.HTTP_200_OK,
                "csrf": csrf_token,
                "sessionid": sessionid
            }, status=status.HTTP_200_OK)
        else:
            return Response({"status": "fail"}, status=status.HTTP_401_UNAUTHORIZED)
class CategoryViewSet(viewsets.ModelViewSet):
    queryset = Category.objects.all()
    serializer_class = CategorySerializer
    permission_classes = [AllowAny]

    @action(detail=True, methods=['get'])
    def subcategories(self, request, pk=None):
        category = self.get_object()
        subcategories = Subcategory.objects.filter(category=category)
        serializer = SubCategorySerializer(subcategories, many=True)
        return Response(serializer.data)

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        if serializer.is_valid():
            self.perform_create(serializer)
            return Response({"status": "success", "data": serializer.data, "statuscode": status.HTTP_201_CREATED}, status=status.HTTP_201_CREATED)
        else:
            return Response({"status": "fail", "errors": serializer.errors,"statuscode":status.HTTP_400_BAD_REQUEST}, status=status.HTTP_400_BAD_REQUEST)

    def destroy(self, request, *args, **kwargs):
        try:
            item = self.get_object()
            self.perform_destroy(item)
            return Response({"status": "success", "message": "Category deleted successfully.", "statuscode":status.HTTP_204_NO_CONTENT}, status=status.HTTP_204_NO_CONTENT)
        except Exception as e:
            return Response({"status": "fail", "message": str(e), "statuscode":status.HTTP_400_BAD_REQUEST}, status=status.HTTP_400_BAD_REQUEST)
class SubCategoryViewSet(viewsets.ModelViewSet):
    queryset = Subcategory.objects.all()
    serializer_class = SubCategorySerializer
    permission_classes = [AllowAny]

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        if serializer.is_valid():
            self.perform_create(serializer)
            return Response({"status": "success", "data": serializer.data,"statuscode":status.HTTP_201_CREATED}, status=status.HTTP_201_CREATED)
        else:
            return Response({"status": "fail", "errors": serializer.errors,"statuscode":status.HTTP_400_BAD_REQUEST}, status=status.HTTP_400_BAD_REQUEST)

    def destroy(self, request, *args, **kwargs):
        try:
            item = self.get_object()
            self.perform_destroy(item)
            return Response({"status": "success", "message": "Subcategory deleted successfully.", "statuscode":status.HTTP_204_NO_CONTENT}, status=status.HTTP_204_NO_CONTENT)
        except Exception as e:
            return Response({"status": "fail", "message": str(e)}, status=status.HTTP_400_BAD_REQUEST)
class ItemViewSet(viewsets.ModelViewSet):
    queryset = Item.objects.all()
    serializer_class = ItemSerializer
    permission_classes = [AllowAny]
    pagination_class = ItemPagination

    def get_queryset(self):
        # Only show items from active sellers or admin items and visible
        return Item.objects.filter(
            is_visible=True
        ).filter(
            Q(seller__isnull=True) |  # Admin items
            Q(seller__is_active=True)  # Items from active sellers
        ).exclude(
            Q(seller__is_active=False)  # Explicitly exclude inactive seller items
        )

    def perform_create(self, serializer):
        user = self.request.user
        if user.is_authenticated and hasattr(user, 'sellerprofile'):
            seller_profile = user.sellerprofile
            if not seller_profile.is_active:
                raise PermissionDenied("Inactive sellers cannot add new products")
            return serializer.save(seller=seller_profile, seller_code=seller_profile.seller_code)
        else:
            return serializer.save()

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        if serializer.is_valid():
            # Create the item first
            item = self.perform_create(serializer)
            
            # Handle multiple image uploads
            images = request.FILES.getlist('images')
            for index, image in enumerate(images):
                ItemImage.objects.create(
                    item=item,
                    image=image,
                    order=index
                )
            
            return Response({"status": "success", "data": serializer.data,"statuscode":status.HTTP_201_CREATED}, status=status.HTTP_201_CREATED)
        else:
            return Response({"status": "fail", "errors": serializer.errors,"statuscode":status.HTTP_400_BAD_REQUEST}, status=status.HTTP_400_BAD_REQUEST)

    def destroy(self, request, *args, **kwargs):
        try:
            item = self.get_object()
            self.perform_destroy(item)
            return Response({"status": "success","statuscode":status.HTTP_204_NO_CONTENT,"message": "Item deleted successfully."}, status=status.HTTP_204_NO_CONTENT)
        except Exception as e:
            return Response({"status": "fail","statuscode":status.HTTP_400_BAD_REQUEST, "message": str(e)}, status=status.HTTP_400_BAD_REQUEST)

#Affilate code start from here

class AffiliateLinkViewSet(viewsets.ModelViewSet):
    print("jiii")
    queryset = AffiliateLink.objects.all()
    serializer_class = AffiliateLinkSerializer
    permission_classes = [AllowAny]

    @action(detail=True, methods=['post'])
    def create_link(self, request, pk=None):
        item = get_object_or_404(Item, pk=pk)

        # Extract the affiliate username from the request data
        affiliate_username = request.data.get('affiliate_username')
        affiliate = get_object_or_404(Affiliate, user__username=affiliate_username)

        # Check if an affiliate link already exists for this affiliate and item
        affiliate_link, created = AffiliateLink.objects.get_or_create(affiliate=affiliate, item=item)

        # If the link already exists, return the existing link without creating a new one
        if not created:
            return Response({
                'message': "Affiliate link already exists.",
                'link': affiliate_link.generate_link(),
                'affiliate_link': AffiliateLinkSerializer(affiliate_link).data
            })

        # If a new link was created, return the new link data
        return Response({
            'message': "New affiliate link created.",
            'link': affiliate_link.generate_link(),
            'affiliate_link': AffiliateLinkSerializer(affiliate_link).data
        })



class ShareItemView(APIView):
    permission_classes = [AllowAny]

    print(f"Received request for unique_code")

    def get(self, request, unique_code):
        print(f"Received request for unique_code: {unique_code}")
        # Fetch the AffiliateLink object using the unique_code
        affiliate_link = get_object_or_404(AffiliateLink, unique_code=unique_code)
        # Get the associated Item
        item = affiliate_link.item
        # Serialize the item data, including images
        serializer = ItemSerializer(item, context={'request': request})
        # Return the item details
        return Response(serializer.data, status=status.HTTP_200_OK)

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAdminUser
from django.db.models import Sum, Count
from django.utils.timezone import now
from .models import Order, Category, Item,OrderItem
from .serializers import AdminInsightsSerializer, SalesByCategorySerializer, SalesByRegionSerializer, TopSellingProductSerializer, MonthWiseSalesSerializer, YearSalesSerializer
class AdminInsightsAPIView(APIView):
    permission_classes = [AllowAny]

    def get(self, request):
        today = now().date()

                # Total Sales Today
        total_sales_today = OrderItem.objects.filter(
            order__created_at__date=today,
            order__payment_status='successful'
        ).aggregate(total=Sum('price'))['total'] or 0
        # Sales by Category
        sales_by_category = Category.objects.annotate(
            total_sales=Sum('subcategory__items__order_items__price')
        ).values('name', 'total_sales')
        sales_by_category_list = SalesByCategorySerializer(sales_by_category, many=True).data
        sales_by_category_count = len(sales_by_category_list)

        # Sales by Region
        sales_by_region = Order.objects.filter(payment_status='successful').values('region').annotate(
            total_sales=Sum('order_items__price')
        )


        sales_by_region_list = SalesByRegionSerializer(sales_by_region, many=True).data
        sales_by_region_count = len(sales_by_region_list)

        # Top Selling Products
        top_selling_products = Item.objects.annotate(
            sales_count=Count('order_items__order')
        ).order_by('-sales_count')[:10]

        top_selling_products_list = TopSellingProductSerializer(top_selling_products, many=True, context={'request': request}).data
        top_selling_products_count = len(top_selling_products_list)

        # Dispatched Orders
        dispatched_orders = Order.objects.filter(delivery_status='dispatched')
        dispatched_orders_list = [{
            'order_id': d_order.id,
            'order_items': [item.item.name for item in d_order.order_items.all()],
            'total_value': sum(item.price for item in d_order.order_items.all()),
            'order_time': d_order.created_at.strftime('%H:%M:%S'),  # Time in HH:MM:SS format
            'order_month': d_order.created_at.strftime('%B'),  # Full month name
            'order_year': d_order.created_at.strftime('%Y'),  # Year in YYYY format
            'region': d_order.region
        } for d_order in dispatched_orders]
        dispatched_orders_count = dispatched_orders.count()

        # Pending Orders
        pending_orders = Order.objects.filter(delivery_status='pending')
        pending_orders_list = [{
            'order_id': order.id,
            'order_items': [item.item.name for item in order.order_items.all()],
            'total_value': sum(item.price for item in order.order_items.all()),
            'order_time': order.created_at.strftime('%H:%M:%S'),  # Time in HH:MM:SS format
            'order_month': order.created_at.strftime('%B'),  # Full month name
            'order_year': order.created_at.strftime('%Y'),  # Year in YYYY format
            'region': order.region
        } for order in pending_orders]
        pending_orders_count = pending_orders.count()

        # Cancelled Orders
        cancelled_orders = Order.objects.filter(delivery_status='cancelled')
        cancelled_orders_list = [str(order.id) for order in cancelled_orders]
        cancelled_orders_count = cancelled_orders.count()

        # Low Stock Alerts
        low_stock_alerts = Item.objects.filter(stock__lte=10)
        low_stock_alerts_list = [item.name for item in low_stock_alerts]
        low_stock_alerts_count = low_stock_alerts.count()

        # Month-Wise Sales
        from django.db.models.functions import TruncMonth
        month_wise_sales = (
            Order.objects.filter(payment_status='successful')
            .annotate(month=TruncMonth('created_at'))  # Group by month
            .values('month')
            .annotate(total_sales=Sum('order_items__price'))  # Sum sales in each month
            .order_by('month')
        )

        formatted_sales = [{
            'month': sale['month'].strftime('%Y-%m'),  # Format as YYYY-MM
            'total_sales': sale['total_sales']
        } for sale in month_wise_sales]
        month_wise_sales_list = MonthWiseSalesSerializer(formatted_sales, many=True).data
        month_wise_sales_count = len(month_wise_sales_list)

        # Year Sales
        from django.db.models.functions import TruncYear
        year_sales = (
            Order.objects.filter(payment_status='successful')
            .annotate(year=TruncYear('created_at'))  # Group by year
            .values('year')
            .annotate(total_sales=Sum('order_items__price'))  # Sum sales in each year
            .order_by('year')
        )

        formatted_year_sales = [{
            'year': sale['year'].year,  # Get the year value
            'total_sales': sale['total_sales']
        } for sale in year_sales]
        year_sales_list = YearSalesSerializer(formatted_year_sales, many=True).data
        year_sales_count = len(year_sales_list)

        data = {
            'total_sales_today': total_sales_today,
            'sales_by_category': sales_by_category_list,
            'sales_by_category_count': sales_by_category_count,
            'sales_by_region': sales_by_region_list,
            'sales_by_region_count': sales_by_region_count,
            'top_selling_products': top_selling_products_list,
            'top_selling_products_count': top_selling_products_count,
            'dispatched_orders': dispatched_orders_list,
            'dispatched_orders_count': dispatched_orders_count,
            'pending_orders': pending_orders_list,
            'pending_orders_count': pending_orders_count,
            'cancelled_orders': cancelled_orders_list,
            'cancelled_orders_count': cancelled_orders_count,
            'low_stock_alerts': low_stock_alerts_list,
            'low_stock_alerts_count': low_stock_alerts_count,
            'month_wise_sales': month_wise_sales_list,
            'month_wise_sales_count': month_wise_sales_count,
            'year_sales': year_sales_list,
            'year_sales_count': year_sales_count,
        }

        serializer = AdminInsightsSerializer(data)
        return Response(data)


# class ItemSearchView(ListAPIView):
#     serializer_class = ItemSerializer
#     permission_classes = [AllowAny]
#
#     def get_queryset(self):
#         query = self.request.query_params.get('q')
#         if query:
#             keywords = query.split()
#             q_objects = Q()
#             for keyword in keywords:
#                 # Perform fuzzy matching
#                 matching_keywords = Keyword.objects.all()
#                 best_match, score = process.extractOne(keyword, [kw.name for kw in matching_keywords])
#
#                 if score >= 70:  # Threshold for fuzzy match
#                     q_objects |= Q(keywords__name__iexact=best_match)
#
#             return Item.objects.filter(q_objects).distinct()
#
#         return Item.objects.none()
#
#     def get(self, request, *args, **kwargs):
#         queryset = self.get_queryset()
#         if queryset.exists():
#             serializer = self.get_serializer(queryset, many=True)
#             return Response(serializer.data, status=status.HTTP_200_OK)
#         return Response({'detail': 'No items found matching the keywords.'}, status=status.HTTP_404_NOT_FOUND)


class ItemSearchView(ListAPIView):

    serializer_class = ItemSerializer
    permission_classes = [AllowAny]

    def get_queryset(self):
        query = self.request.query_params.get('q', '').strip()

        # Return an empty queryset if query length is less than 2 characters
        if len(query) < 2:
            return Item.objects.none()

        # Use database search first (faster)
        keywords = query.split()
        q_objects = Q()

        for keyword in keywords:
            # Perform direct substring matching in the database (much faster)
            q_objects |= Q(name__icontains=keyword) | Q(keywords__name__icontains=keyword)

        # First attempt to return matches from the database
        results = Item.objects.filter(q_objects).distinct()

        # If no direct database results, fallback to fuzzy matching
        if not results.exists():
            all_item_names = Item.objects.values_list('name', flat=True)
            all_keywords = Keyword.objects.values_list('name', flat=True)
            for keyword in keywords:
                # Fuzzy matching for item names
                best_item_match, item_score = process.extractOne(keyword, all_item_names)
                if item_score >= 70:  # Fuzzy match threshold
                    q_objects |= Q(name__icontains=best_item_match)

                # Fuzzy matching for keywords
                best_keyword_match, keyword_score = process.extractOne(keyword, all_keywords)
                if keyword_score >= 70:  # Fuzzy match threshold
                    q_objects |= Q(keywords__name__icontains=best_keyword_match)

            # Run the fuzzy-matched query
            results = Item.objects.filter(q_objects).distinct()

        return results

    def get(self, request, *args, **kwargs):
        query = self.request.query_params.get('q', '').strip()

        # Check if the query is less than 2 characters


        queryset = self.get_queryset()

        if queryset.exists():
            serializer = self.get_serializer(queryset, many=True)
            return Response(serializer.data, status=status.HTTP_200_OK)

        # If no items match the query, return a message indicating no results found
        return Response({'detail': 'No items found','status':status.HTTP_200_OK}, status=status.HTTP_200_OK)

class KeywordCreateView(CreateAPIView):
    permission_classes = [AllowAny]
    queryset = Keyword.objects.all()
    serializer_class = KeywordSerializer
class Subcategoryview(mixins.ListModelMixin, viewsets.GenericViewSet):
    queryset = Item.objects.all()  # Define a queryset here
    serializer_class = ItemSerializer
    pagination_class = StandardResultsSetPagination  # Use custom pagination
    permission_classes = [AllowAny]

    def list(self, request, *args, **kwargs):
        subcategory_name = request.query_params.get('q')
        if subcategory_name:
            try:
                subcategory = Subcategory.objects.get(id=subcategory_name)
                self.queryset = self.queryset.filter(subcategory=subcategory)
            except Subcategory.DoesNotExist:
                return Response({"error": "Subcategory not found"}, status=status.HTTP_404_NOT_FOUND)
        return super().list(request, *args, **kwargs)

from django.shortcuts import render, redirect
from django.core.files.storage import FileSystemStorage
import shutil
import os
from .models import Category, Subcategory, Item  # Import your models
from django.conf import settings

def upload_data_folder(request):
    if request.method == 'POST':
        uploaded_folder = request.FILES.get('data_folder')
        if uploaded_folder:
            # Save the uploaded folder
            fs = FileSystemStorage(location='/tmp')
            fs.save(uploaded_folder.name, uploaded_folder)
            extracted_path = os.path.join('/tmp', uploaded_folder.name)

            # Move the uploaded folder to the desired location
            final_directory = os.path.join(settings.BASE_DIR, 'media', 'data')
            shutil.move(extracted_path, final_directory)

            # Run your management command to generate categories, subcategories, and items
            os.system('python manage.py populate_database')

            return redirect('success_page')  # Redirect to a success page or wherever you want

    return render(request, 'upload.html')

class ListSigma(viewsets.ModelViewSet):
    queryset = Category.objects.all()
    serializer_class = CategorySerializerto
    permission_classes = [AllowAny]


@api_view(['GET'])
@permission_classes([AllowAny])
def search_items(request):
    query = request.GET.get('q', '')
    if not query:
        return Response({"status": "fail", "message": "Search query is required"}, status=status.HTTP_400_BAD_REQUEST)

    # Search in items from active sellers only and visible
    items = Item.objects.filter(
        Q(name__icontains=query) |
        Q(sku__icontains=query) |
        Q(specification__icontains=query),
        Q(seller__isnull=True) | Q(seller__is_active=True),
        Q(is_visible=True)
    ).exclude(Q(seller__is_active=False))

    serializer = ItemSerializer(items, many=True)
    return Response({"status": "success", "data": serializer.data})

@api_view(['GET'])
@permission_classes([AllowAny])
def get_items_by_category(request, category_id, subcategory_id):
    try:
        # Get items from active sellers only and visible
        items = Item.objects.filter(
            Q(subcategory_id=subcategory_id),
            Q(subcategory__category_id=category_id),
            Q(seller__isnull=True) | Q(seller__is_active=True),
            Q(is_visible=True)
        ).exclude(Q(seller__is_active=False))

        serializer = ItemSerializer(items, many=True)
        return Response({"status": "success", "data": serializer.data})
    except Exception as e:
        return Response({"status": "fail", "message": str(e)}, status=status.HTTP_400_BAD_REQUEST)

def item_search_page(request):
    return render(request, 'search.html')

from rest_framework import viewsets
from .models import Advertisement
from .serializers import AdvertisementSerializer

class AdvertisementViewSet(viewsets.ModelViewSet):
    queryset = Advertisement.objects.all()
    serializer_class = AdvertisementSerializer
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.decorators import action
from rest_framework import status
from .models import User, Address
from .serializers import UserSerializer, AddressSerializer

# UserViewSet with authentication
class UserViewSet(viewsets.ModelViewSet):
    queryset = User.objects.all()
    serializer_class = UserSerializer
    permission_classes = [AllowAny]  # Ensure only authenticated users access this view

    @action(detail=True, methods=['post'])
    def update_wallet(self, request, pk=None):
        user = self.get_object()
        new_amount = request.data.get('wallet_amount')
        if new_amount is not None:
            user.wallet_amount = new_amount
            user.save()
            return Response({'status': 'wallet updated', 'wallet_amount': user.wallet_amount})
        return Response({'error': 'Invalid data'}, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=True, methods=['post'])
    def add_address(self, request, pk=None):
        user = self.get_object()
        serializer = AddressSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save(user=user)
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# AddressViewSet with authentication
class AddressViewSet(viewsets.ModelViewSet):
    queryset = Address.objects.all()
    serializer_class = AddressSerializer
    permission_classes = [AllowAny]  # Ensure only authenticated users access this view

    def get_queryset(self):
        user = self.request.user
        if user.is_authenticated:
            return Address.objects.filter(user=user)
        return Address.objects.none()  # Return empty queryset for anonymous users
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from django.utils.crypto import get_random_string
from django.core.signing import BadSignature, SignatureExpired, TimestampSigner
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from .models import AffiliateUser
from .serializers import AffiliateUserSerializer

# Define the signer for views
signer = TimestampSigner()

def send_email(subject, body, to_email):
    # Email account credentials
    smtp_server = 'smtpout.secureserver.net'
    smtp_port = 465  # Use 587 for TLS
    smtp_user = 'info@quirckart.com'
    smtp_password = 'aayush2306'

    # Create the email content
    msg = MIMEMultipart()
    msg['From'] = smtp_user
    msg['To'] = to_email
    msg['Subject'] = subject

    # Attach the body to the email
    msg.attach(MIMEText(body, 'html'))  # Change 'plain' to 'html'
    print("Email trying!")

    # Connect to the SMTP server and send the email
    try:
        with smtplib.SMTP_SSL(smtp_server, smtp_port) as server:
            server.login(smtp_user, smtp_password)
            server.send_message(msg)
            return Response(meesafe= "send", status=status.HTTP_201_CREATED)
    except Exception as e:
        return Response(meesafe= "not send", status=status.HTTP_201_CREATED)


@api_view(['POST'])
def create_affiliate_user(request):
    if request.method == 'POST':
        name = request.data.get('name')
        mobile = request.data.get('mobile')
        email = request.data.get('email')
        age = request.data.get('age')
        address = request.data.get('address')
        document_type = request.data.get('document_type')
        document_upload = request.FILES.get('document_upload')

        # Generate a random 6-digit uid
        uid = get_random_string(length=6, allowed_chars='0123456789')

        # Create the new affiliate user
        affiliate_user = AffiliateUser.objects.create(
            uid=uid,
            name=name,
            mobile=mobile,
            email=email,
            age=age,
            address=address,
            document_type=document_type,
            document_upload=document_upload
        )

        print("trying")
        # Serialize the data
        serializer = AffiliateUserSerializer(affiliate_user, context={'request': request})
        document_upload_url = serializer.data.get('document_upload', None)
        # Prepare email content
        subject = "New Affiliate User Created"
        body = f"""
        <html>
                <body>
                    <p>Hello,</p>
                
                    <p>A new affiliate user has been created with the following details:</p>
                
                    <ul>
                        <li><strong>Name:</strong> {affiliate_user.name}</li>
                        <li><strong>Mobile:</strong> {affiliate_user.mobile}</li>
                        <li><strong>Age:</strong> {affiliate_user.age}</li>
                        <li><strong>Address:</strong> {affiliate_user.address}</li>
                        <li><strong>Document Type:</strong> {affiliate_user.document_type}</li>
                        <li><strong>Document Upload:</strong> <a href="{document_upload_url}">View Document</a></li>
                    </ul>
                
                    <p><strong>Approval Links:</strong></p>
                   <ul style="list-style: none; padding: 0; display: flex; gap: 10px;">
            <li>
                <a href="{serializer.data['approve_link']}" 
                   style="background-color: green; color: white; font-weight: bold; 
                          padding: 10px 20px; text-decoration: none; border-radius: 5px; 
                          display: inline-block; text-align: center;">
                    Approve
                </a>
            </li>
            <li>
                <a href="{serializer.data['reject_link']}" 
                   style="background-color: orange; color: white; 
                          padding: 10px 20px; text-decoration: none; border-radius: 5px; 
                          display: inline-block; text-align: center;">
                    Reject
                </a>
            </li>
            <li>
                <a href="{serializer.data['block_link']}" 
                   style="background-color: red; color: white; 
                          padding: 10px 20px; text-decoration: none; border-radius: 5px; 
                          display: inline-block; text-align: center;">
                    Block
                </a>
            </li>
        </ul>
                    <p>Please take the necessary action.</p>
                
                    <p>Regards,<br>Auto Admin</p>
                </body>
                </html>
        """

        # Send email
        print("trying")
        send_email(subject, body, "nvsaroy@gmail.com")  # Change this to the desired recipient

        return Response(serializer.data, status=status.HTTP_201_CREATED)

        return Response({'error': 'Invalid request method'}, status=status.HTTP_400_BAD_REQUEST)



import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from django.utils.crypto import get_random_string
from django.core.signing import BadSignature, SignatureExpired, TimestampSigner
from django.contrib.auth.hashers import make_password,check_password
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from .models import AffiliateUser, AffiliateLogin
from .serializers import AffiliateUserSerializer

# Define the signer for views
signer = TimestampSigner()

def send_email2(subject, body, to_email):
    smtp_server = 'smtpout.secureserver.net'
    smtp_port = 465
    smtp_user = 'info@quirckart.com'
    smtp_password = 'aayush2306'

    msg = MIMEMultipart()
    msg['From'] = smtp_user
    msg['To'] = to_email
    msg['Subject'] = subject
    msg.attach(MIMEText(body, 'plain'))

    try:
        with smtplib.SMTP_SSL(smtp_server, smtp_port) as server:
            server.login(smtp_user, smtp_password)
            server.send_message(msg)
            print("Email sent successfully!")
    except Exception as e:
        print(f"Error: {e}")

@api_view(['GET'])
def secure_change_affiliate_status(request, token):
    try:
        signed_data = signer.unsign(token, max_age=86400)  # 24 hours expiration
        uid, status_change = signed_data.split(':')

        # Get the affiliate user
        affiliate_user = AffiliateUser.objects.get(uid=uid)

        # Update the status
        affiliate_user.status = status_change
        affiliate_user.save()

        if status_change == 'approved':
            # Create affiliate login credentials
            username = f'affiliate_{affiliate_user.uid}'
            password = get_random_string(length=10)  # Generate a random password
            hashed_password = make_password(password)

            affiliate_login = AffiliateLogin.objects.create(
                affiliate_user=affiliate_user,
                username=username,
                password=hashed_password
            )
            Affiliate.objects.get_or_create(
            user = affiliate_login,
            points = 0
            )

            # Prepare email content with login credentials
            subject = "Your Affiliate Account has been Approved"
            body = f"""
            Hello {affiliate_user.name},

            Your affiliate account has been approved! Here are your login credentials:

            Username: {username}
            Password: {password}

            Please login at: [Your Login URL]

            Regards,
            Your Company Name
            """
            send_email2(subject, body, affiliate_user.email)  # Send email to the affiliate user

        return Response({'message': f'Status changed to {status_change}'}, status=status.HTTP_200_OK)

    except (BadSignature, SignatureExpired):
        return Response({'error': 'Invalid or expired link'}, status=status.HTTP_400_BAD_REQUEST)

from django.contrib.auth.hashers import check_password
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .models import AffiliateLogin
from rest_framework_simplejwt.tokens import RefreshToken

@method_decorator(csrf_exempt, name='dispatch')
class AffiliateLoginView(APIView):
    def post(self, request):
        serializer = AffiliateLoginSerializer(data=request.data)
        if serializer.is_valid():
            username = serializer.validated_data['username']
            password = serializer.validated_data['password']

            try:
                user = AffiliateLogin.objects.get(username=username)

                # Use check_password to verify the raw password against the hashed password
                if check_password(password, user.password):
                    # Password is correct, generate tokens
                    refresh = RefreshToken.for_user(user)

                    return Response({
                        "status": "OK",
                        "id": user.id,
                        "username": user.username,
                        "token": str(refresh.access_token),  # Access token
                        "refresh_token": str(refresh),      # Refresh token
                        "user_details": {
                            "id": user.id,
                            "username": user.username
                        }
                    }, status=status.HTTP_200_OK)
                else:
                    # Invalid password
                    return Response({"error": "Invalid password"}, status=status.HTTP_401_UNAUTHORIZED)

            except AffiliateLogin.DoesNotExist:
                return Response({"error": "User not found"}, status=status.HTTP_404_NOT_FOUND)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


from rest_framework import status
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from .models import Item, Comment, Reply
from .serializers import CommentSerializer, ReplySerializer
from django.contrib.auth.models import User
from rest_framework.permissions import IsAdminUser

@api_view(['POST'])
def add_comment(request, item_id):
    try:
        item = Item.objects.get(id=item_id)
    except Item.DoesNotExist:
        return Response({'error': 'Item not found'}, status=status.HTTP_404_NOT_FOUND)

    content = request.data.get('content', '')
    if content:
        comment = Comment.objects.create(item=item, user=request.user, content=content)
        return Response({'message': 'Comment added successfully'}, status=status.HTTP_201_CREATED)
    return Response({'error': 'Content cannot be empty'}, status=status.HTTP_400_BAD_REQUEST)

@api_view(['POST'])
def reply_to_comment(request, comment_id):
    try:
        comment = Comment.objects.get(id=comment_id)
    except Comment.DoesNotExist:
        return Response({'error': 'Comment not found'}, status=status.HTTP_404_NOT_FOUND)

    content = request.data.get('content', '')
    if content:
        reply, created = Reply.objects.get_or_create(comment=comment, user=request.user, content=content)
        if created:
            return Response({'message': 'Reply added successfully'}, status=status.HTTP_201_CREATED)
        else:
            return Response({'error': 'A reply to this comment already exists'}, status=status.HTTP_400_BAD_REQUEST)
    return Response({'error': 'Content cannot be empty'}, status=status.HTTP_400_BAD_REQUEST)

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .models import AffiliateLink, Affiliate
from .serializers import AffiliateLinkSerializer
from django.shortcuts import get_object_or_404

from rest_framework import viewsets
from rest_framework.response import Response
from django.shortcuts import get_object_or_404
from .models import AffiliateLink, Affiliate
from .serializers import AffiliateLinkSerializer

from rest_framework import viewsets
from rest_framework.response import Response
from django.shortcuts import get_object_or_404
from .models import AffiliateLink, Affiliate
from .serializers import AffiliateLinkSerializer

class AffiliateLinkViewSet(viewsets.ModelViewSet):
    queryset = AffiliateLink.objects.all()
    serializer_class = AffiliateLinkSerializer

    def get_affiliate_links(self, request, username=None):
        # Get affiliate using the username
        affiliate = get_object_or_404(Affiliate, user=username)

        # Retrieve all links associated with the affiliate
        affiliate_links = AffiliateLink.objects.filter(affiliate=affiliate)

        # Check if no links found, return 200 OK with "No links found" message
        if not affiliate_links.exists():
            return Response({"message": "No links found"}, status=200)

        # Serialize the affiliate links data
        serializer = AffiliateLinkSerializer(affiliate_links, many=True)

        # Prepare response including total points of the affiliate
        response_data = {
            "affiliate_username": affiliate.user.username,
            "total_tokens": affiliate.points,  # Display the total points of the affiliate
            "links": serializer.data  # All the links generated by the affiliate
        }

        return Response(response_data)
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import razorpay
from django.conf import settings
import json
import time

# Initialize the Razorpay client with settings
client = razorpay.Client(auth=(settings.RAZORPAY_API_KEY, settings.RAZORPAY_API_SECRET))

@csrf_exempt
def initiate_payment(request):
    if request.method == 'POST':
        try:
            # Validate amount
            amount = request.POST.get('amount')
            if not amount:
                return JsonResponse({'error': 'Amount is required'}, status=400)
            
            try:
                amount = int(amount)
            except ValueError:
                return JsonResponse({'error': 'Invalid amount format'}, status=400)
                
            if amount <= 0:
                return JsonResponse({'error': 'Amount must be greater than 0'}, status=400)

            # Prepare order data
            data = {
                'amount': amount * 100,  # Convert to paise
                'currency': 'INR',
                'payment_capture': '1',
                'notes': {
                    'custom_order_id': f'order_{int(time.time())}'
                }
            }

            # Create Razorpay order
            order_response = client.order.create(data=data)

            return JsonResponse({
                'id': order_response['id'],
                'amount': order_response['amount'],
                'currency': order_response['currency'],
                'status': 'success'
            }, status=200)

        except razorpay.errors.BadRequestError as e:
            print(f"Razorpay Bad Request Error: {str(e)}")
            return JsonResponse({'error': 'Invalid payment request'}, status=400)
        except razorpay.errors.AuthenticationError as e:
            print(f"Razorpay Authentication Error: {str(e)}")
            return JsonResponse({'error': 'Payment service authentication failed'}, status=500)
        except razorpay.errors.ServerError as e:
            print(f"Razorpay Server Error: {str(e)}")
            return JsonResponse({'error': 'Payment service temporarily unavailable'}, status=503)
        except Exception as e:
            print(f"Payment initiation error: {str(e)}")
            return JsonResponse({'error': 'Payment initiation failed'}, status=500)
    else:
        return JsonResponse({'error': 'Invalid request method'}, status=405)


from rest_framework import viewsets
from .models import Order
from .serializers import OrderSerializer

class OrderViewSet(viewsets.ModelViewSet):
    queryset = Order.objects.all()
    serializer_class = OrderSerializer

from rest_framework import viewsets
from .models import Customer
from .serializers import CustomerSerializer

class CustomerViewSet(viewsets.ModelViewSet):
    queryset = Customer.objects.all()
    serializer_class = CustomerSerializer

from django.contrib.auth.models import User
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.permissions import AllowAny
from django.contrib.auth import authenticate
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework_simplejwt.exceptions import InvalidToken
from rest_framework_simplejwt.tokens import AccessToken
from .models import Customer, CartItem
from .serializers import CustomerUserSerializer

class CustomerLoginView(APIView):
    permission_classes = [AllowAny]

    def post(self, request, *args, **kwargs):
        username = request.data.get('username')
        password = request.data.get('password')

        if not username or not password:
            return Response({
                'status': 'error',
                'message': 'Username and password are required.'
            }, status=400)

        user = authenticate(username=username, password=password)
        
        if user is not None:
            # Existing user - login
            customer, created = Customer.objects.get_or_create(
                user=user,
                defaults={'name': user.username, 'phone': user.username}
            )
        else:
            # New user - register
            try:
                if User.objects.filter(username=username).exists():
                    return Response({
                        'status': 'error',
                        'message': 'Invalid credentials'
                    }, status=401)
                
                user = User.objects.create_user(username=username, password=password)
                customer = Customer.objects.create(
                    user=user,
                    name=username,
                    phone=username,
                    email=''
                )
            except Exception as e:
                return Response({
                    'status': 'error',
                    'message': f'Error creating account: {e}'
                }, status=500)

        # Fetch cart items
        cart_items = CartItem.objects.filter(customer=customer)
        cart_data = [{'id': item.id, 'item_id': item.item.id, 'item_name': item.item.name,
                      'item_sku': item.item.sku, 'item_price': str(item.item.price),
                      'item_image': request.build_absolute_uri(item.item.image1.url) if item.item.image1 else None,
                      'quantity': item.quantity, 'total_price': str(item.item.price * item.quantity)}
                     for item in cart_items]
        
        total_cart_items = sum(item['quantity'] for item in cart_data)
                
        # Generate JWT tokens
        refresh = RefreshToken.for_user(user)
        print(refresh)
        return Response({
                    'status': 'success',
            'message': 'Login successful' if not 'created' in locals() else 'New customer created and logged in',
                    'access_token': str(refresh.access_token),
                    'refresh_token': str(refresh),
                    'customer_id': customer.id,
                    'user_details': {
                        'id': user.id,
                        'username': user.username,
                        'email': user.email,
                        'customer_name': customer.name,
                        'customer_phone': customer.phone,
                        'wallet_amount': str(customer.wallet_amount)
                    },
                    'cart_details': {
                'total_items': total_cart_items,
                'cart_items': cart_data,
                'cart_count': len(cart_data)
                    }
        }, status=200 if not 'created' in locals() else 201)

class GetUserDetailsView(APIView):
    permission_classes = [AllowAny]

    def post(self, request, *args, **kwargs):
        access_token = request.data.get('access_token')
        
        if not access_token:
            return Response({
                'status': 'error',
                'message': 'Access token is required.'
            }, status=status.HTTP_400_BAD_REQUEST)

        try:
            # Decode and verify the access token
            token = AccessToken(access_token)
            user_id = token.payload.get('user_id')
            
            if not user_id:
                return Response({
                    'status': 'error',
                    'message': 'Invalid token: user_id not found.'
                }, status=status.HTTP_401_UNAUTHORIZED)
            
            # Get the user
            try:
                user = User.objects.get(id=user_id)
            except User.DoesNotExist:
                return Response({
                    'status': 'error',
                    'message': 'User not found.'
                }, status=status.HTTP_404_NOT_FOUND)
            
            # Get or create customer
            customer, created = Customer.objects.get_or_create(user=user)
            
            # Fetch cart items for the customer
            cart_items = CartItem.objects.filter(customer=customer)
            cart_data = []
            total_cart_items = 0
            
            for cart_item in cart_items:
                cart_data.append({
                    'id': cart_item.id,
                    'item_id': cart_item.item.id,
                    'item_name': cart_item.item.name,
                    'item_sku': cart_item.item.sku,
                    'item_price': str(cart_item.item.price),
                    'item_image': request.build_absolute_uri(cart_item.item.image1.url) if cart_item.item.image1 else None,
                    'quantity': cart_item.quantity,
                    'total_price': str(cart_item.item.price * cart_item.quantity)
                })
                total_cart_items += cart_item.quantity
            
            return Response({
                'status': 'success',
                'message': 'User details retrieved successfully',
                'customer_id': customer.id,
                'user_details': {
                    'id': user.id,
                    'username': user.username,
                    'email': user.email,
                    'customer_name': customer.name,
                    'customer_phone': customer.phone,
                    'wallet_amount': str(customer.wallet_amount)
                },
                'cart_details': {
                    'total_items': total_cart_items,
                    'cart_items': cart_data,
                    'cart_count': len(cart_data)
                }
            }, status=status.HTTP_200_OK)
            
        except InvalidToken:
            return Response({
                'status': 'error',
                'message': 'Invalid or expired access token.'
            }, status=status.HTTP_401_UNAUTHORIZED)
        except Exception as e:
            return Response({
                'status': 'error',
                'message': f'Error processing request: {str(e)}'
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

class CustomerRegisterView(APIView):
    permission_classes = [AllowAny]

    def post(self, request, *args, **kwargs):
        username = request.data.get('username')
        password = request.data.get('password')
        email = request.data.get('email', '')
        name = request.data.get('name', '')
        phone = request.data.get('phone', '')

        if not username or not password:
            return Response({
                'status': 'error',
                'message': 'Username and password are required.'
            }, status=status.HTTP_400_BAD_REQUEST)

        # Check if user already exists
        if User.objects.filter(username=username).exists():
            return Response({
                'status': 'error',
                'message': 'Username already exists.'
            }, status=status.HTTP_400_BAD_REQUEST)

        try:
            # Create new user
            user = User.objects.create_user(
                username=username,
                password=password,
                email=email
            )
            
            # Create customer profile
            customer = Customer.objects.create(
                user=user,
                name=name,
                email=email,
                phone=phone
            )
            
            # Generate JWT tokens
            refresh = RefreshToken.for_user(user)
            
            return Response({
                'status': 'success',
                'message': 'Customer registered successfully',
                'access_token': str(refresh.access_token),
                'refresh_token': str(refresh),
                'customer_id': customer.id,
                'user_details': {
                    'id': user.id,
                    'username': user.username,
                    'email': user.email,
                    'customer_name': customer.name,
                    'customer_phone': customer.phone,
                    'wallet_amount': str(customer.wallet_amount)
                },
                'cart_details': {
                    'total_items': 0,
                    'cart_items': [],
                    'cart_count': 0
                }
            }, status=status.HTTP_201_CREATED)
            
        except Exception as e:
            return Response({
                'status': 'error',
                'message': f'Error creating account: {str(e)}'
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

class CustomerRefreshTokenView(APIView):
    permission_classes = [AllowAny]

    def post(self, request, *args, **kwargs):
        refresh_token = request.data.get('refresh_token')
        
        if not refresh_token:
            return Response({
                'status': 'error',
                'message': 'Refresh token is required.'
            }, status=status.HTTP_400_BAD_REQUEST)

        try:
            # Verify and decode the refresh token
            refresh = RefreshToken(refresh_token)
            
            # Generate new access token
            new_access_token = str(refresh.access_token)
            
            return Response({
                'status': 'success',
                'message': 'Token refreshed successfully',
                'access_token': new_access_token,
                'refresh_token': str(refresh)  # Return the same refresh token
            }, status=status.HTTP_200_OK)
            
        except InvalidToken:
            return Response({
                'status': 'error',
                'message': 'Invalid or expired refresh token.'
            }, status=status.HTTP_401_UNAUTHORIZED)
        except Exception as e:
            return Response({
                'status': 'error',
                'message': f'Error refreshing token: {str(e)}'
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

class ReactAppView(TemplateView):
    template_name = "index.html"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        # Add any additional context data if needed
        return context

from django.http import JsonResponse
import requests

def fetch_pin_code(request):
    # Get filter_code from query parameters
    filter_code = request.GET.get('filter_code')

    if not filter_code:
        return JsonResponse({"error": "filter_code query parameter is required."}, status=400)

    # Delhivery API URL
    url = f"https://track.delhivery.com/c/api/pin-codes/json/?token=454efe120c467091556c613bada8af5b3bab3bc5&filter_codes={filter_code}"
    headers = {'Accept': 'application/json'}

    try:
        # Make the GET request
        response = requests.get(url, headers=headers)
        response.raise_for_status()  # Raise error for HTTP issues
        return JsonResponse(response.json(), status=response.status_code, safe=False)
    except requests.exceptions.RequestException as e:
        return JsonResponse({"error": str(e)}, status=500)

def fetch_delivery_charges(request):
    """
    Fetch delivery charges based on the given parameters.
    """
    url = "https://track.delhivery.com/api/kinko/v1/invoice/charges/.json"
    headers = {
        'Authorization': 'Token 454efe120c467091556c613bada8af5b3bab3bc5',
    }
    params = {
        'md': request.GET.get('md', 'S'),
        'ss': request.GET.get('ss', 'Delivered'),
        'd_pin': request.GET.get('d_pin'),
        'o_pin': request.GET.get('o_pin'),
        'cgm': request.GET.get('cgm'),
    }

    try:
        response = requests.get(url, headers=headers, params=params)
        response.raise_for_status()  # Raise an error for HTTP codes 4xx/5xx
        return JsonResponse(response.json(), safe=False)
    except requests.exceptions.RequestException as e:
        return JsonResponse({"error": str(e)}, status=400)

from django.http import JsonResponse
import json
import requests
from .models import PickupLocation, ReturnDetails
import random
@csrf_exempt
def createshipment(request):
    random_order_number = random.randint(100000, 999999)  # Generate a 6-digit random number
    try:
        data = json.loads(request.body)
    except json.JSONDecodeError:
        return JsonResponse({"error": "Invalid JSON payload"}, status=400)

    try:
        pickup_location = PickupLocation.objects.get(id=data.get("pickup_location_id"))
        return_details = ReturnDetails.objects.get(id=data.get("return_details_id"))
    except PickupLocation.DoesNotExist:
        return JsonResponse({"error": "Invalid pickup location ID"}, status=404)
    except ReturnDetails.DoesNotExist:
        return JsonResponse({"error": "Invalid return details ID"}, status=404)

    # Prepare payload
    payload = {
        "pickup_location": {
            "name": pickup_location.name,
            "add": pickup_location.address,
            "city": pickup_location.city,
            "state": pickup_location.state,
            "pin": pickup_location.pin,
            "phone": pickup_location.phone,
            "country": pickup_location.country,
        },
        "shipments": [
            {
                **shipment,  # Take shipment data from the frontend
                "return_name": return_details.name,
                "return_add": return_details.address,
                "return_city": return_details.city,
                "return_state": return_details.state,
                "return_pin": return_details.pin,
                "return_phone": return_details.phone,
                "return_country": return_details.country,
                "order": str(random_order_number),
            }
            for shipment in data.get("shipments", [])
        ],
    }
    payload = f"format=json&data={json.dumps(payload)}"
    #print(payload)
    # Send the payload to Delhivery API
    url = "https://track.delhivery.com/api/cmu/create.json"
    headers = {
        "Authorization": "Token 454efe120c467091556c613bada8af5b3bab3bc5",
        "Content-Type": "application/json",
    }
    response = requests.post(url, headers=headers, data=payload)
    res_json = response.json()

    shipment_status = "Shipment Created" if res_json.get("success") else "Shipment Failed"
    order = OrderDashboard.objects.get(id=data.get("order_id"))
    order.status = shipment_status
    print(order.name)
    order.save()
    return JsonResponse(shipment_status, safe=False)

from rest_framework.viewsets import ModelViewSet
from .models import AdvertisementNew
from .serializers import AdvertisementSerializer1

class AdvertisementViewSet1(ModelViewSet):
    queryset = AdvertisementNew.objects.all()
    serializer_class = AdvertisementSerializer1


# ... existing imports ...

class OrderDashboardViewSet(viewsets.ModelViewSet):
    queryset = OrderDashboard.objects.all().order_by('-order_datetime')
    serializer_class = OrderDashboardSerializer
    permission_classes = [AllowAny]

    def get_queryset(self):
        queryset = OrderDashboard.objects.all()
        
        # Add filters for date range if needed
        start_date = self.request.query_params.get('start_date', None)
        end_date = self.request.query_params.get('end_date', None)
        
        if start_date and end_date:
            queryset = queryset.filter(
                order_datetime__range=[start_date, end_date]
            )
        
        return queryset.order_by('-order_datetime')
    
    def perform_create(self, serializer):
        # Get the user from mobile number
        mobile = self.request.data.get('order_by')
        try:
            user = User.objects.get(username=mobile)
            # Create the order
            order = serializer.save(order_by=user)
            # Process items and associate with sellers
            items_data = self.request.data.get('items', [])
            for item_data in items_data:
                try:
                    # Get the item to check seller information
                    item = Item.objects.get(sku=item_data['sku'])
                    # Prevent duplicate items for the same order and SKU
                    if not OrderDashboardItem.objects.filter(order=order, sku=item_data['sku']).exists():
                        OrderDashboardItem.objects.create(
                            order=order,
                            name=item_data['name'],
                            price=item_data['price'],
                            sku=item_data['sku'],
                            quantity=item_data['quantity']
                        )
                except Item.DoesNotExist:
                    continue
            return order
        except User.DoesNotExist:
            raise serializers.ValidationError("User not found")


@csrf_exempt
@api_view(['POST'])
@permission_classes([AllowAny])
def refund_payment(request):
    print("refund initiated")
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            payment_id = data.get("payment_id")
            amount = data.get("amount")

            if not payment_id or not amount:
                return JsonResponse({"success": False, "error": "Payment ID and amount are required"}, status=400)

            response = client.payment.refund(payment_id, {
                "amount": amount,
                "speed": "normal",
                "notes": {
                    "notes_key_1": "Beam me up Scotty.",
                    "notes_key_2": "Engage"
                },
                "receipt": payment_id
            })

            return JsonResponse({"success": True, "response": response})
        except Exception as e:
            return JsonResponse({"success": False, "error": str(e)}, status=400)

    return JsonResponse({"error": "Invalid request method"}, status=405)



@api_view(['POST'])
@csrf_exempt
@permission_classes([AllowAny])
def send_cancellation_sms(request):
    number = request.data.get('mobile')
    order_id = request.data.get('order_id')

    if not number or not order_id:
        return JsonResponse({'error': 'Missing mobile number or order ID'}, status=400)

    text = f"Your order {order_id} has been canceled. We hope you will shop with us in the future. For assistance, contact support. Thank you! QUIRCKART"

    url = "http://ultronsms.com/api/mt/SendSMS"
    params = {
        "user": "Quickart",
        "password": "Quickart@199",
        "senderid": "QRCKRT",
        "channel": "Trans",
        "DCS": "0",
        "flashsms": "0",
        "number": number,
        "text": text,
        "route": "2",
        "peid": "1701173157667049239",
        "DLTTemplateId": "1707173322738790419",
    }

    try:
        response = requests.get(url, params=params)
        if response.status_code == 200:
            return JsonResponse({
                "message": "Cancellation SMS sent successfully!",
                "response": response.json()
            })
        else:
            return JsonResponse({
                "error": "Failed to send SMS",
                "status_code": response.status_code,
                "response_text": response.text
            }, status=500)
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)



@api_view(['POST'])
@csrf_exempt
@permission_classes([AllowAny])
def send_order_sms(request):
    number = request.data.get('mobile')
    order_id = request.data.get('order_id')
    manage_link = request.data.get('manage_link')

    if not number or not order_id or not manage_link:
        return JsonResponse({'error': 'Missing one or more required fields'}, status=400)

    text = f"Your order {order_id} has been successfully placed! We'll notify you once it's shipped. Manage: {manage_link} QUIRCKART"

    url = "http://ultronsms.com/api/mt/SendSMS"
    params = {
        "user": "Quickart",
        "password": "Quickart@199",
        "senderid": "QRCKRT",
        "channel": "Trans",
        "DCS": "0",
        "flashsms": "0",
        "number": number,
        "text": text,
        "route": "2",
        "peid": "1701173157667049239",
        "DLTTemplateId": "1707173328895093499",
    }

    try:
        response = requests.get(url, params=params)
        if response.status_code == 200:
            return JsonResponse({
                "message": "Order SMS sent successfully!",
                "response": response.json()
            })
        else:
            return JsonResponse({
                "error": "Failed to send SMS",
                "status_code": response.status_code,
                "response_text": response.text
            }, status=500)
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)


@api_view(['GET'])
def get_orders_by_user_id(request, user_id):
    print("hii")
    try:
       
        orders = OrderDashboard.objects.filter(order_by__username=user_id).order_by('-order_datetime')
        serializer = OrderDashboardSerializer(orders, many=True)
        print(serializer.data)
        return Response(serializer.data, status=status.HTTP_200_OK)
    except Exception as e:
        return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)

from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated, IsAdminUser
from django.core.mail import send_mail
from django.utils.crypto import get_random_string
from .models import SellerRequest, SellerProfile
from .serializers import SellerRequestSerializer, SellerProfileSerializer

class SellerRequestViewSet(viewsets.ModelViewSet):
    queryset = SellerRequest.objects.all()
    serializer_class = SellerRequestSerializer
    permission_classes = [AllowAny]  # Allow anyone to create a request

    def get_queryset(self):
        if self.request.user.is_staff:
            return SellerRequest.objects.all()
        return SellerRequest.objects.filter(user=self.request.user)

    def create(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)
            serializer.is_valid(raise_exception=True)
            self.perform_create(serializer)
            headers = self.get_success_headers(serializer.data)
            return Response(
                {
                    "status": "success",
                    "data": serializer.data,
                    "message": "Seller request created successfully"
                },
                status=status.HTTP_201_CREATED,
                headers=headers
            )
        except serializers.ValidationError as e:
            return Response(
                {
                    "status": "error",
                    "message": str(e),
                    "errors": e.detail
                },
                status=status.HTTP_400_BAD_REQUEST
            )
        except Exception as e:
            return Response(
                {
                    "status": "error",
                    "message": f"An error occurred: {str(e)}"
                },
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

    def perform_create(self, serializer):
        serializer.save()

    @action(detail=True, methods=['post'], permission_classes=[IsAdminUser])
    def approve(self, request, pk=None):
        seller_request = self.get_object()
        seller_request.approve()
        return Response({"message": "Seller approved and login credentials sent."})

    @action(detail=True, methods=['post'], permission_classes=[IsAdminUser])
    def reject(self, request, pk=None):
        seller_request = self.get_object()
        seller_request.status = 'Rejected'
        seller_request.save()
        return Response({"message": "Seller request rejected."})

class SellerProfileViewSet(viewsets.ModelViewSet):
    queryset = SellerProfile.objects.all()
    serializer_class = SellerProfileSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        if self.request.user.is_staff:
            return SellerProfile.objects.all()
        return SellerProfile.objects.filter(user=self.request.user)

    def list(self, request, *args, **kwargs):
        queryset = self.get_queryset()
        if not queryset.exists():
            return Response({
                "status": "error",
                "message": "No seller profile found"
            }, status=status.HTTP_404_NOT_FOUND)
        
        serializer = self.get_serializer(queryset.first())
        return Response({
            "status": "success",
            "data": serializer.data
        })

    @action(detail=False, methods=['post'])
    def toggle_active_status(self, request):
        seller_profile = self.get_queryset().first()
        if not seller_profile:
            return Response({
                "status": "error",
                "message": "Seller profile not found"
            }, status=status.HTTP_404_NOT_FOUND)

        # Toggle the active status
        new_status = not seller_profile.is_active
        seller_profile.is_active = new_status
        seller_profile.save()

        # Update all products' visibility based on seller status
        Item.objects.filter(seller=seller_profile).update(
            is_visible=new_status
        )

        return Response({
            "status": "success",
            "data": {
                "is_active": seller_profile.is_active,
                "message": f"Seller status updated to {'active' if new_status else 'inactive'}. All products have been {'made visible' if new_status else 'hidden'}."
            }
        })

    @action(detail=False, methods=['get'])
    def my_products(self, request):
        seller_profile = self.get_queryset().first()
        if not seller_profile:
            return Response({
                "status": "error",
                "message": "Seller profile not found"
            }, status=status.HTTP_404_NOT_FOUND)

        products = Item.objects.filter(seller=seller_profile)
        serializer = ItemSerializer(products, many=True)
        return Response({
            "status": "success",
            "data": serializer.data
        })

    @action(detail=False, methods=['get'])
    def my_orders(self, request):
        seller_profile = self.get_queryset().first()
        if not seller_profile:
            return Response({
                "status": "error",
                "message": "Seller profile not found"
            }, status=status.HTTP_404_NOT_FOUND)

        # Get all orders that have items belonging to this seller
        orders = OrderDashboard.objects.filter(
            items__sku__in=Item.objects.filter(
                seller_identifier=seller_profile.seller_id,
                seller_code=seller_profile.seller_code
            ).values_list('sku', flat=True)
        ).distinct().order_by('-order_datetime')

        serializer = OrderDashboardSerializer(orders, many=True)
        return Response({
            "status": "success",
            "data": serializer.data
        })

    def perform_destroy(self, instance):
        # Delete all products belonging to this seller before deleting the seller profile
        with transaction.atomic():
            Item.objects.filter(seller=instance).delete()
            super().perform_destroy(instance)

    @action(detail=False, methods=['get'])
    def dashboard_stats(self, request):
        seller_profile = self.get_queryset().first()
        if not seller_profile:
            return Response({
                "status": "error",
                "message": "Seller profile not found"
            }, status=status.HTTP_404_NOT_FOUND)

        try:
            # Get all orders for this seller
            orders = OrderDashboard.objects.filter(
                items__sku__in=Item.objects.filter(
                    seller_identifier=seller_profile.seller_id,
                    seller_code=seller_profile.seller_code
                ).values_list('sku', flat=True)
            ).distinct()

            # Calculate total revenue
            total_revenue = 0.0  # Initialize as float
            total_orders = orders.count()
            total_products = Item.objects.filter(
                seller_identifier=seller_profile.seller_id,
                seller_code=seller_profile.seller_code
            ).count()

            # Calculate revenue from each order
            for order in orders:
                for item in order.items.all():
                    try:
                        item_obj = Item.objects.get(sku=item.sku)
                        if item_obj.seller_identifier == seller_profile.seller_id:
                            total_revenue += float(item.price) * float(item.quantity)
                    except (Item.DoesNotExist, ValueError, TypeError):
                        continue

            # Get recent orders
            recent_orders = orders.order_by('-order_datetime')[:5]
            recent_orders_data = OrderDashboardSerializer(recent_orders, many=True).data

            # Format the response data
            stats = {
                "totalRevenue": str(round(total_revenue, 2)),  # Convert to string with 2 decimal places
                "totalOrders": total_orders,
                "totalProducts": total_products,
                "recentOrders": recent_orders_data
            }

            return Response({
                "status": "success",
                "data": stats
            })
        except Exception as e:
            return Response({
                "status": "error",
                "message": str(e)
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

@csrf_exempt
@api_view(['POST'])
@permission_classes([AllowAny])
def seller_login(request):
    if request.method != 'POST':
        return Response({
            "status": "error",
            "message": "Only POST method is allowed"
        }, status=status.HTTP_405_METHOD_NOT_ALLOWED)

    try:
        email = request.data.get('email')
        password = request.data.get('password')

        if not email or not password:
            return Response({
                "status": "error",
                "message": "Please provide both email and password"
            }, status=status.HTTP_400_BAD_REQUEST)

        # Find the user by email
        try:
            user = User.objects.get(email=email)
        except User.DoesNotExist:
            return Response({
                "status": "error",
                "message": "No user found with this email"
            }, status=status.HTTP_404_NOT_FOUND)
        
        # Check if user has an approved seller request
        seller_request = SellerRequest.objects.filter(user=user, status='approved').first()
        
        if not seller_request:
            return Response({
                "status": "error",
                "message": "No approved seller account found for this email"
            }, status=status.HTTP_401_UNAUTHORIZED)

        # Check if seller profile exists
        seller_profile = SellerProfile.objects.filter(user=user).first()
        if not seller_profile:
            # Create seller profile if it doesn't exist
            seller_profile = SellerProfile.objects.create(
                user=user,
                seller_request=seller_request,
                shop_name=seller_request.shop_name,
                contact_number=seller_request.contact_number,
                address=seller_request.address,
                business_details=seller_request.business_details
            )

        # Authenticate the user
        user = authenticate(username=user.username, password=password)
        
        if user is not None:
            # Generate tokens
            refresh = RefreshToken.for_user(user)
            
            return Response({
                "status": "success",
                "token": str(refresh.access_token),
                "refresh_token": str(refresh),
                "user_details": {
                    "id": user.id,
                    "email": user.email,
                    "shop_name": seller_profile.shop_name,
                    "contact_number": seller_profile.contact_number,
                    "address": seller_profile.address
                }
            }, status=status.HTTP_200_OK)
        else:
            return Response({
                "status": "error",
                "message": "Invalid credentials"
            }, status=status.HTTP_401_UNAUTHORIZED)

    except Exception as e:
        return Response({
            "status": "error",
            "message": str(e)
        }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

class SellerOrderViewSet(viewsets.ModelViewSet):
    serializer_class = OrderSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        try:
            seller_profile = SellerProfile.objects.get(user=self.request.user)
            # Get orders that have items belonging to this seller
            return Order.objects.filter(
                orderitem__item__seller_identifier=seller_profile.seller_id
            ).distinct()
        except SellerProfile.DoesNotExist:
            return Order.objects.none()

class SellerProductViewSet(viewsets.ModelViewSet):
    serializer_class = ItemSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        try:
            seller_profile = SellerProfile.objects.get(user=self.request.user)
            return Item.objects.filter(seller_identifier=seller_profile.seller_id)
        except SellerProfile.DoesNotExist:
            return Item.objects.none()

    def perform_create(self, serializer):
        try:
            seller_profile = SellerProfile.objects.get(user=self.request.user)
            return serializer.save(seller=seller_profile)
        except SellerProfile.DoesNotExist:
            raise PermissionDenied("Seller profile not found")

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        if serializer.is_valid():
            # Create the item first
            item = self.perform_create(serializer)
            
            # Handle multiple image uploads
            images = request.FILES.getlist('images')
            for index, image in enumerate(images):
                ItemImage.objects.create(
                    item=item,
                    image=image,
                    order=index
                )
            
            return Response({"status": "success", "data": serializer.data,"statuscode":status.HTTP_201_CREATED}, status=status.HTTP_201_CREATED)
        else:
            return Response({"status": "fail", "errors": serializer.errors,"statuscode":status.HTTP_400_BAD_REQUEST}, status=status.HTTP_400_BAD_REQUEST)

class AdminOrderViewSet(viewsets.ModelViewSet):
    serializer_class = OrderSerializer
    permission_classes = [IsAdminUser]
    queryset = Order.objects.all()

class AdminProductViewSet(viewsets.ModelViewSet):
    serializer_class = ItemSerializer
    permission_classes = [IsAdminUser]
    queryset = Item.objects.all()

class RecentlyViewedViewSet(viewsets.ModelViewSet):
    permission_classes = [AllowAny]
    serializer_class = ItemSerializer

    def get_queryset(self):
        user = self.request.user if self.request.user.is_authenticated else None
        session_id = self.request.query_params.get('session_id')
        
        if not user and not session_id:
            return Item.objects.none()
        
        viewed_items = RecentlyViewed.objects.filter(
            user=user if user else None,
            session_id=session_id if not user else None
        ).order_by('-viewed_at')[:10]
        
        return [viewed.item for viewed in viewed_items]

    def create(self, request, *args, **kwargs):
        try:
            item_id = request.data.get('item_id')
            session_id = request.data.get('session_id')
            
            if not item_id:
                return Response({'error': 'item_id is required'}, status=400)
            
            if not session_id:
                return Response({'error': 'session_id is required'}, status=400)

            with transaction.atomic():
                try:
                    item = Item.objects.get(id=item_id)
                except Item.DoesNotExist:
                    return Response({'error': f'Item with id {item_id} not found'}, status=404)

                user = request.user if request.user.is_authenticated else None
                
                # Create or update the recently viewed entry
                RecentlyViewed.objects.update_or_create(
                    user=user,
                    session_id=session_id if not user else None,
                    item=item,
                    defaults={'viewed_at': timezone.now()}
                )
                
                return Response({
                    'status': 'success',
                    'message': 'Item tracked successfully',
                    'item_id': item_id,
                    'session_id': session_id
                }, status=201)

        except Exception as e:
            return Response({
                'error': str(e),
                'detail': 'An error occurred while tracking the item'
            }, status=500)

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def user_orders(request, username):
    orders = OrderDashboard.objects.filter(order_by__username=username).order_by('-order_datetime')
    serializer = OrderDashboardSerializer(orders, many=True, context={'request': request})
    return Response(serializer.data)