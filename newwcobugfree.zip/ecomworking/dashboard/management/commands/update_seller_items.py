from django.core.management.base import BaseCommand
from django.db import transaction
from dashboard.models import Item, SellerProfile

class Command(BaseCommand):
    help = 'Updates existing items with seller identifiers and codes'

    def handle(self, *args, **options):
        with transaction.atomic():
            items = Item.objects.filter(seller__isnull=False)
            updated_count = 0

            for item in items:
                if item.seller:
                    item.seller_identifier = item.seller.seller_id
                    item.seller_code = item.seller.seller_code
                    item.save()
                    updated_count += 1

            self.stdout.write(
                self.style.SUCCESS(f'Successfully updated {updated_count} items with seller identifiers and codes')
            ) 