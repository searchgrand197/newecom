from django.core.management.base import BaseCommand
from dashboard.models import Item, SellerProfile

class Command(BaseCommand):
    help = 'Assigns products matching a filter to a given seller by shop_name.'

    def add_arguments(self, parser):
        parser.add_argument('shop_name', type=str, help='The shop_name of the seller to assign products to.')
        parser.add_argument('--sku_prefix', type=str, help='Assign only products whose SKU starts with this prefix.', default=None)
        parser.add_argument('--ids', nargs='+', type=int, help='Assign only products with these IDs.', default=None)

    def handle(self, *args, **options):
        shop_name = options['shop_name']
        sku_prefix = options['sku_prefix']
        ids = options['ids']

        try:
            seller = SellerProfile.objects.get(shop_name=shop_name)
        except SellerProfile.DoesNotExist:
            self.stdout.write(self.style.ERROR(f'SellerProfile with shop_name "{shop_name}" does not exist.'))
            return

        products = Item.objects.none()
        if sku_prefix:
            products = Item.objects.filter(sku__startswith=sku_prefix)
        elif ids:
            products = Item.objects.filter(id__in=ids)
        else:
            self.stdout.write(self.style.ERROR('You must provide either --sku_prefix or --ids.'))
            return

        updated_count = 0
        for item in products:
            item.seller = seller
            item.seller_code = seller.seller_code
            item.save()
            updated_count += 1
        self.stdout.write(self.style.SUCCESS(f'Successfully assigned {updated_count} products to seller "{shop_name}".')) 