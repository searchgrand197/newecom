# myapp/management/commands/delete_all_data.py

from django.core.management.base import BaseCommand
from dashboard.models import Category, Subcategory, Item

class Command(BaseCommand):
    help = 'Delete all categories, subcategories, and items from the database'

    def handle(self, *args, **kwargs):
        # Delete all items
        items_count = Item.objects.count()
        Item.objects.all().delete()
        self.stdout.write(self.style.SUCCESS(f'Successfully deleted {items_count} items'))

        # Delete all subcategories
        subcategories_count = Subcategory.objects.count()
        Subcategory.objects.all().delete()
        self.stdout.write(self.style.SUCCESS(f'Successfully deleted {subcategories_count} subcategories'))

        # Delete all categories
        categories_count = Category.objects.count()
        Category.objects.all().delete()
        self.stdout.write(self.style.SUCCESS(f'Successfully deleted {categories_count} categories'))
