from rest_framework import serializers
from .models import SpecialCoupon, CouponForAll, OneTimeCoupon
from django.contrib.auth import get_user_model

User = get_user_model()

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'username', 'email']

class BaseCouponSerializer(serializers.ModelSerializer):
    def validate(self, data):
        if data.get('discount_type') == 'amount' and data.get('max_discount_amount') is not None:
            raise serializers.ValidationError({
                'max_discount_amount': 'Maximum discount amount should not be set for amount-based coupons.'
            })
        return data

class SpecialCouponSerializer(BaseCouponSerializer):
    coupon_for = UserSerializer(many=True, read_only=True)
    coupon_for_ids = serializers.PrimaryKeyRelatedField(
        queryset=User.objects.all(),
        many=True,
        write_only=True,
        required=False
    )

    class Meta:
        model = SpecialCoupon
        fields = ['id', 'code', 'discount_type', 'discount', 'max_discount_amount', 
                 'min_purchase_amount', 'description', 'active', 'coupon_for', 'coupon_for_ids']

    def create(self, validated_data):
        coupon_for_ids = validated_data.pop('coupon_for_ids', [])
        coupon = SpecialCoupon.objects.create(**validated_data)
        if coupon_for_ids:
            coupon.coupon_for.set(coupon_for_ids)
        return coupon

    def update(self, instance, validated_data):
        coupon_for_ids = validated_data.pop('coupon_for_ids', None)
        for attr, value in validated_data.items():
            setattr(instance, attr, value)
        instance.save()
        if coupon_for_ids is not None:
            instance.coupon_for.set(coupon_for_ids)
        return instance

class CouponForAllSerializer(BaseCouponSerializer):
    class Meta:
        model = CouponForAll
        fields = ['id', 'code', 'discount_type', 'discount', 'max_discount_amount',
                 'min_purchase_amount', 'description', 'valid_from', 'valid_to', 'active']

class OneTimeCouponSerializer(BaseCouponSerializer):
    used_by = UserSerializer(many=True, read_only=True)

    class Meta:
        model = OneTimeCoupon
        fields = ['id', 'code', 'discount_type', 'discount', 'max_discount_amount',
                 'min_purchase_amount', 'description', 'valid_from', 'valid_to', 'active', 'used_by'] 