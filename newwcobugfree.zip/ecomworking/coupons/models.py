from django.db import models
from django.conf import settings
from django.core.exceptions import ValidationError
from decimal import Decimal

# Create your models here.

PERCENT = 'percent'
AMOUNT = 'amount'
DISCOUNT_TYPE_CHOICES = [
    (PERCENT, 'Percent'),
    (AMOUNT, 'Amount'),
]

class BaseCoupon(models.Model):
    code = models.CharField(max_length=50, unique=True)
    discount_type = models.CharField(max_length=10, choices=DISCOUNT_TYPE_CHOICES, default=AMOUNT)
    discount = models.DecimalField(max_digits=5, decimal_places=2)
    max_discount_amount = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True,
        help_text="Maximum discount amount for percentage coupons")
    min_purchase_amount = models.DecimalField(max_digits=10, decimal_places=2, default=0,
        help_text="Minimum purchase amount required to use this coupon")
    description = models.TextField(blank=True, null=True)
    active = models.BooleanField(default=True)

    class Meta:
        abstract = True

    def clean(self):
        if self.discount <= 0:
            raise ValidationError('Discount must be greater than 0.')
        
        if self.discount_type == PERCENT:
            if not (0 < self.discount <= 100):
                raise ValidationError('Percent discount must be between 0 and 100.')
            if not self.max_discount_amount:
                raise ValidationError('Maximum discount amount is required for percentage coupons.')
            if self.max_discount_amount <= 0:
                raise ValidationError('Maximum discount amount must be greater than 0.')
        else:  # AMOUNT type
            if self.max_discount_amount is not None:
                raise ValidationError('Maximum discount amount should not be set for amount-based coupons.')
        
        if self.min_purchase_amount < 0:
            raise ValidationError('Minimum purchase amount cannot be negative.')

    def calculate_discount(self, total_amount):
        if total_amount < self.min_purchase_amount:
            return Decimal('0')
        
        if self.discount_type == PERCENT:
            discount = (total_amount * self.discount) / Decimal('100')
            return min(discount, self.max_discount_amount)
        return min(self.discount, total_amount)  # Ensure discount doesn't exceed total amount

class SpecialCoupon(BaseCoupon):
    coupon_for = models.ManyToManyField(settings.AUTH_USER_MODEL, blank=True, related_name='special_coupons')

    def __str__(self):
        return self.code

class CouponForAll(BaseCoupon):
    valid_from = models.DateTimeField()
    valid_to = models.DateTimeField()

    def __str__(self):
        return self.code

class OneTimeCoupon(BaseCoupon):
    valid_from = models.DateTimeField()
    valid_to = models.DateTimeField()
    used_by = models.ManyToManyField(settings.AUTH_USER_MODEL, blank=True, related_name='used_coupons')

    def __str__(self):
        return self.code
