# Customer Authentication API

This document describes the JWT-based authentication endpoints for customers.

## Endpoints

### 1. Customer Login (Auto Register)
**URL:** `POST /api/customer/login/`

**Description:** Authenticate existing customer OR create new customer if doesn't exist. Returns JWT tokens and customer details.

**Request Body:**
```json
{
    "username": "customer_username",
    "password": "customer_password"
}
```

**Success Response for Existing User (200):**
```json
{
    "status": "success",
    "message": "Login successful",
    "access_token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9...",
    "refresh_token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9...",
    "customer_id": 1,
    "user_details": {
        "id": 1,
        "username": "customer_username",
        "email": "customer@example.com",
        "customer_name": "John Doe",
        "customer_phone": "1234567890",
        "wallet_amount": "100.00"
    }
}
```

**Success Response for New User (201):**
```json
{
    "status": "success",
    "message": "New customer created and logged in",
    "access_token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9...",
    "refresh_token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9...",
    "customer_id": 2,
    "user_details": {
        "id": 2,
        "username": "new_username",
        "email": "",
        "customer_name": "new_username",
        "customer_phone": "",
        "wallet_amount": "0.00"
    }
}
```

**Error Response (401):**
```json
{
    "status": "error",
    "message": "Invalid credentials"
}
```

**How it works:**
1. If user exists and password is correct → **Login** (200 status)
2. If user doesn't exist → **Auto Register** (201 status)
3. If user exists but password is wrong → **Error** (401 status)

### 2. Customer Registration (Full Details)
**URL:** `POST /api/customer/register/`

**Description:** Register a new customer with full details and return JWT tokens.

**Request Body:**
```json
{
    "username": "new_customer",
    "password": "secure_password",
    "email": "newcustomer@example.com",
    "name": "New Customer",
    "phone": "9876543210"
}
```

**Success Response (201):**
```json
{
    "status": "success",
    "message": "Customer registered successfully",
    "access_token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9...",
    "refresh_token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9...",
    "customer_id": 2,
    "user_details": {
        "id": 2,
        "username": "new_customer",
        "email": "newcustomer@example.com",
        "customer_name": "New Customer",
        "customer_phone": "9876543210",
        "wallet_amount": "0.00"
    }
}
```

**Error Response (400):**
```json
{
    "status": "error",
    "message": "Username already exists."
}
```

### 3. Refresh Token
**URL:** `POST /api/customer/refresh/`

**Description:** Refresh an expired access token using a valid refresh token.

**Request Body:**
```json
{
    "refresh_token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9..."
}
```

**Success Response (200):**
```json
{
    "status": "success",
    "message": "Token refreshed successfully",
    "access_token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9...",
    "refresh_token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9..."
}
```

**Error Response (401):**
```json
{
    "status": "error",
    "message": "Invalid or expired refresh token."
}
```

## Usage Examples

### Using cURL

**Login (Auto Register):**
```bash
# For existing user
curl -X POST http://localhost:8000/api/customer/login/ \
  -H "Content-Type: application/json" \
  -d '{"username": "existinguser", "password": "testpass"}'

# For new user (will auto-register)
curl -X POST http://localhost:8000/api/customer/login/ \
  -H "Content-Type: application/json" \
  -d '{"username": "newuser", "password": "newpass"}'
```

**Register with Full Details:**
```bash
curl -X POST http://localhost:8000/api/customer/register/ \
  -H "Content-Type: application/json" \
  -d '{"username": "newuser", "password": "newpass", "email": "new@example.com", "name": "New User", "phone": "1234567890"}'
```

**Refresh Token:**
```bash
curl -X POST http://localhost:8000/api/customer/refresh/ \
  -H "Content-Type: application/json" \
  -d '{"refresh_token": "your_refresh_token_here"}'
```

### Using JavaScript/Fetch

**Login (Auto Register):**
```javascript
const loginData = {
    username: 'testuser',
    password: 'testpass'
};

fetch('/api/customer/login/', {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json',
    },
    body: JSON.stringify(loginData)
})
.then(response => response.json())
.then(data => {
    if (data.status === 'success') {
        // Store tokens
        localStorage.setItem('access_token', data.access_token);
        localStorage.setItem('refresh_token', data.refresh_token);
        localStorage.setItem('customer_id', data.customer_id);
        
        if (response.status === 200) {
            console.log('Existing user logged in:', data.user_details);
        } else if (response.status === 201) {
            console.log('New user created and logged in:', data.user_details);
        }
    } else {
        console.error('Login failed:', data.message);
    }
});
```

**Using Access Token for Authenticated Requests:**
```javascript
const accessToken = localStorage.getItem('access_token');

fetch('/api/protected-endpoint/', {
    method: 'GET',
    headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
    }
})
.then(response => response.json())
.then(data => console.log(data));
```

## Token Configuration

- **Access Token Lifetime:** 24 hours (14400 minutes)
- **Refresh Token Lifetime:** 1 day
- **Token Type:** JWT (JSON Web Token)

## Security Notes

1. Always use HTTPS in production
2. Store tokens securely (localStorage for web apps, secure storage for mobile apps)
3. Implement token refresh logic to automatically refresh expired access tokens
4. Clear tokens on logout
5. Never expose refresh tokens in client-side code that could be accessed by malicious scripts

## Key Differences

| Feature | Login Endpoint | Register Endpoint |
|---------|---------------|-------------------|
| **Existing User** | ✅ Login (200) | ❌ Error (400) |
| **New User** | ✅ Auto Register (201) | ✅ Register (201) |
| **Full Details** | ❌ Basic info only | ✅ Email, name, phone |
| **Use Case** | Simple login/register | Complete registration | 