from rest_framework import serializers
from .models import Rating, RatingImage
from django.contrib.auth.models import User

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'username', 'first_name', 'last_name']

class RatingImageSerializer(serializers.ModelSerializer):
    class Meta:
        model = RatingImage
        fields = ['id', 'image', 'uploaded_at']

class RatingSerializer(serializers.ModelSerializer):
    comment = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    user = UserSerializer(read_only=True)
    images = RatingImageSerializer(many=True, read_only=True)
    uploaded_images = serializers.ListField(
        child=serializers.ImageField(),
        write_only=True,
        required=False
    )

    class Meta:
        model = Rating
        fields = [
            'id', 'user', 'item', 'rating', 'comment', 
            'created_at', 'updated_at', 'is_verified_purchase',
            'images', 'uploaded_images'
        ]
        read_only_fields = ['user', 'created_at', 'updated_at', 'is_verified_purchase']

    def create(self, validated_data):
        print(f"Creating rating with validated_data: {validated_data}")
        uploaded_images = validated_data.pop('uploaded_images', [])
        print(f"Uploaded images: {uploaded_images}")
        
        rating = Rating.objects.create(**validated_data)
        print(f"Rating created: {rating}")
        
        for image in uploaded_images:
            print(f"Creating RatingImage for: {image}")
            RatingImage.objects.create(rating=rating, image=image)
        
        return rating

    def update(self, instance, validated_data):
        uploaded_images = validated_data.pop('uploaded_images', [])
        
        # Update rating fields
        for attr, value in validated_data.items():
            setattr(instance, attr, value)
        instance.save()
        
        # Handle new images
        if uploaded_images:
            # Optionally delete old images
            # instance.images.all().delete()
            
            for image in uploaded_images:
                RatingImage.objects.create(rating=instance, image=image)
        
        return instance 