from django.shortcuts import render
from rest_framework import viewsets, permissions, status
from rest_framework.decorators import action
from rest_framework.response import Response
from .models import Rating, RatingImage
from .serializers import RatingSerializer
from django.db.models import Avg, Count
from dashboard.models import Item
from django.db import models

class RatingViewSet(viewsets.ModelViewSet):
    serializer_class = RatingSerializer
    queryset = Rating.objects.all()

    def get_permissions(self):
        """
        Allow anonymous users to view ratings, but require authentication for creating/updating
        """
        if self.action in ['create', 'update', 'partial_update', 'destroy']:
            permission_classes = [permissions.IsAuthenticated]
        else:
            permission_classes = [permissions.AllowAny]
        return [permission() for permission in permission_classes]

    def get_queryset(self):
        queryset = Rating.objects.all()
        
        # Filter by item_id
        item_id = self.request.query_params.get('item_id')
        if item_id:
            queryset = queryset.filter(item_id=item_id)
        
        # Filter by user
        user_id = self.request.query_params.get('user')
        if user_id:
            queryset = queryset.filter(user_id=user_id)
        
        # Filter by rating value
        rating = self.request.query_params.get('rating')
        if rating:
            queryset = queryset.filter(rating=rating)
        
        # Filter by verified purchase
        verified = self.request.query_params.get('verified')
        if verified is not None:
            verified_bool = verified.lower() == 'true'
            queryset = queryset.filter(is_verified_purchase=verified_bool)
        
        # Order by creation date (newest first)
        queryset = queryset.order_by('-created_at')
        
        return queryset

    def perform_create(self, serializer):
        user = self.request.user
        item_id = self.request.data.get('item')
        
        print(f"Creating rating for item {item_id} by user {user}")
        print(f"Request data: {self.request.data}")
        print(f"Request FILES: {self.request.FILES}")
        print(f"Authenticated user: {user}")
        print(f"User ID: {user.id if user else 'None'}")
        
        # Check if user already rated this item
        existing_rating = Rating.objects.filter(user=user, item_id=item_id).first()
        if existing_rating:
            # Update existing rating
            existing_rating.rating = self.request.data.get('rating')
            existing_rating.comment = self.request.data.get('comment', '')
            existing_rating.save()
            print(f"Updated existing rating: {existing_rating}")
            return existing_rating
        
        # You can implement your own logic to verify purchase
        is_verified = False  # Implement your verification logic here
        rating = serializer.save(user=user, is_verified_purchase=is_verified)
        
        print(f"Rating created: {rating}")
        return rating

    @action(detail=False, methods=['get'])
    def item_stats(self, request):
        item_id = request.query_params.get('item_id')
        if not item_id:
            return Response(
                {"error": "item_id is required"}, 
                status=status.HTTP_400_BAD_REQUEST
            )

        stats = Rating.objects.filter(item_id=item_id).aggregate(
            average_rating=Avg('rating'),
            total_ratings=Count('id'),
            verified_ratings=Count('id', filter=models.Q(is_verified_purchase=True))
        )

        # Get rating distribution
        rating_distribution = Rating.objects.filter(item_id=item_id).values('rating').annotate(
            count=Count('id')
        ).order_by('rating')

        return Response({
            **stats,
            'rating_distribution': rating_distribution
        })

    @action(detail=True, methods=['post'])
    def upload_images(self, request, pk=None):
        rating = self.get_object()
        images = request.FILES.getlist('images')

        for image in images:
            RatingImage.objects.create(rating=rating, image=image)

        return Response(
            {"message": "Images uploaded successfully"},
            status=status.HTTP_201_CREATED
        )

    @action(detail=False, methods=['get'])
    def user_stats(self, request):
        user_id = request.query_params.get('user_id')
        if not user_id:
            return Response(
                {"error": "user_id is required"}, 
                status=status.HTTP_400_BAD_REQUEST
            )

        stats = Rating.objects.filter(user_id=user_id).aggregate(
            total_reviews=Count('id'),
            average_rating_given=Avg('rating'),
            verified_reviews=Count('id', filter=models.Q(is_verified_purchase=True))
        )

        return Response(stats)
