#!/usr/bin/env python
"""
Debug script for payment functionality
"""
import os
import sys
import django

# Setup Django environment
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'ecom.settings')
django.setup()

from django.conf import settings
import razorpay

def test_razorpay_connection():
    """Test Razorpay client connection"""
    try:
        print("🔧 Testing Razorpay Configuration...")
        print(f"API Key: {settings.RAZORPAY_API_KEY[:10]}...")
        print(f"API Secret: {settings.RAZORPAY_API_SECRET[:10]}...")
        
        # Initialize client
        client = razorpay.Client(auth=(settings.RAZORPAY_API_KEY, settings.RAZORPAY_API_SECRET))
        
        # Test with a small amount
        test_data = {
            'amount': 100,  # 1 rupee in paise
            'currency': 'INR',
            'payment_capture': '1',
            'notes': {
                'test_order': 'true'
            }
        }
        
        print("📡 Creating test order...")
        order_response = client.order.create(data=test_data)
        
        print("✅ Razorpay connection successful!")
        print(f"Order ID: {order_response['id']}")
        print(f"Amount: {order_response['amount']}")
        print(f"Currency: {order_response['currency']}")
        
        return True
        
    except Exception as e:
        print(f"❌ Razorpay connection failed: {str(e)}")
        return False

def test_payment_view():
    """Test the payment view function directly"""
    try:
        print("\n🔧 Testing Payment View...")
        
        # Import the view function
        from dashboard.views import initiate_payment
        from django.test import RequestFactory
        from django.http import QueryDict
        
        # Create a mock request
        factory = RequestFactory()
        data = QueryDict('amount=100')
        request = factory.post('/initiate-payment/', data)
        
        # Call the view function
        response = initiate_payment(request)
        
        print(f"Status Code: {response.status_code}")
        print(f"Response: {response.content.decode()}")
        
        if response.status_code == 200:
            print("✅ Payment view working correctly!")
            return True
        else:
            print("❌ Payment view returned error")
            return False
            
    except Exception as e:
        print(f"❌ Payment view test failed: {str(e)}")
        return False

if __name__ == "__main__":
    print("🧪 Payment System Debug Test")
    print("=" * 50)
    
    # Test 1: Razorpay connection
    razorpay_ok = test_razorpay_connection()
    
    # Test 2: Payment view
    if razorpay_ok:
        view_ok = test_payment_view()
    else:
        view_ok = False
    
    print("\n" + "=" * 50)
    print("📊 Test Results:")
    print(f"Razorpay Connection: {'✅ PASS' if razorpay_ok else '❌ FAIL'}")
    print(f"Payment View: {'✅ PASS' if view_ok else '❌ FAIL'}")
    
    if razorpay_ok and view_ok:
        print("\n🎉 All tests passed! Payment system should work correctly.")
    else:
        print("\n⚠️  Some tests failed. Check the errors above.") 