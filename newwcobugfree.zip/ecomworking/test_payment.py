#!/usr/bin/env python
"""
Test script for payment endpoint
"""
import os
import sys
import django

# Setup Django environment
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'ecom.settings')
django.setup()

import requests
import json

def test_payment_endpoint():
    """Test the payment initiation endpoint"""
    
    # Test data
    test_amount = 100  # ₹100
    
    # Prepare form data
    data = {
        'amount': str(test_amount)
    }
    
    # Make request to payment endpoint
    try:
        response = requests.post(
            'http://127.0.0.1:8000/initiate-payment/',
            data=data,
            headers={'Content-Type': 'application/x-www-form-urlencoded'}
        )
        
        print(f"Status Code: {response.status_code}")
        print(f"Response Headers: {dict(response.headers)}")
        
        if response.status_code == 200:
            result = response.json()
            print(f"Success Response: {json.dumps(result, indent=2)}")
            
            # Verify expected fields
            expected_fields = ['id', 'amount', 'currency', 'status']
            for field in expected_fields:
                if field in result:
                    print(f"✓ {field}: {result[field]}")
                else:
                    print(f"✗ Missing field: {field}")
                    
        else:
            print(f"Error Response: {response.text}")
            
    except requests.exceptions.ConnectionError:
        print("❌ Connection Error: Make sure Django server is running on http://127.0.0.1:8000")
    except Exception as e:
        print(f"❌ Unexpected error: {str(e)}")

if __name__ == "__main__":
    print("🧪 Testing Payment Endpoint...")
    test_payment_endpoint() 