# cURL Examples for Get User Details API

## API Endpoint
```
POST /api/customer/details/
```

## Step 1: Login to Get Access Token

```bash
curl -X POST http://localhost:8000/api/customer/login/ \
  -H "Content-Type: application/json" \
  -d '{
    "username": "testuser",
    "password": "testpass123"
  }'
```

**Expected Response:**
```json
{
  "status": "success",
  "message": "Login successful",
  "access_token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9...",
  "refresh_token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9...",
  "customer_id": 1,
  "user_details": {
    "id": 1,
    "username": "testuser",
    "email": "test@example.com",
    "customer_name": "Test User",
    "customer_phone": "1234567890",
    "wallet_amount": "100.00"
  },
  "cart_details": {
    "total_items": 3,
    "cart_items": [
      {
        "id": 1,
        "item_id": 10,
        "item_name": "Product A",
        "item_sku": "SKU001",
        "item_price": "50.00",
        "item_image": "http://localhost:8000/media/subcategory_images/product_a.jpg",
        "quantity": 2,
        "total_price": "100.00"
      }
    ],
    "cart_count": 1
  }
}
```

## Step 2: Get User Details Using Access Token

```bash
curl -X POST http://localhost:8000/api/customer/details/ \
  -H "Content-Type: application/json" \
  -d '{
    "access_token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9..."
  }'
```

**Expected Response:**
```json
{
  "status": "success",
  "message": "User details retrieved successfully",
  "customer_id": 1,
  "user_details": {
    "id": 1,
    "username": "testuser",
    "email": "test@example.com",
    "customer_name": "Test User",
    "customer_phone": "1234567890",
    "wallet_amount": "100.00"
  },
  "cart_details": {
    "total_items": 3,
    "cart_items": [
      {
        "id": 1,
        "item_id": 10,
        "item_name": "Product A",
        "item_sku": "SKU001",
        "item_price": "50.00",
        "item_image": "http://localhost:8000/media/subcategory_images/product_a.jpg",
        "quantity": 2,
        "total_price": "100.00"
      }
    ],
    "cart_count": 1
  }
}
```

## Error Examples

### Missing Access Token (400)
```bash
curl -X POST http://localhost:8000/api/customer/details/ \
  -H "Content-Type: application/json" \
  -d '{}'
```

**Response:**
```json
{
  "status": "error",
  "message": "Access token is required."
}
```

### Invalid Token (401)
```bash
curl -X POST http://localhost:8000/api/customer/details/ \
  -H "Content-Type: application/json" \
  -d '{
    "access_token": "invalid_token_here"
  }'
```

**Response:**
```json
{
  "status": "error",
  "message": "Invalid or expired access token."
}
```

## Complete Example Script

```bash
#!/bin/bash

# Configuration
BASE_URL="http://localhost:8000"
LOGIN_ENDPOINT="$BASE_URL/api/customer/login/"
DETAILS_ENDPOINT="$BASE_URL/api/customer/details/"

echo "🚀 Testing Get User Details API"
echo "================================"

# Step 1: Login
echo "📤 Step 1: Login to get access token"
LOGIN_RESPONSE=$(curl -s -X POST "$LOGIN_ENDPOINT" \
  -H "Content-Type: application/json" \
  -d '{
    "username": "testuser",
    "password": "testpass123"
  }')

echo "Login Response: $LOGIN_RESPONSE"

# Extract access token
ACCESS_TOKEN=$(echo $LOGIN_RESPONSE | grep -o '"access_token":"[^"]*"' | cut -d'"' -f4)

if [ -z "$ACCESS_TOKEN" ]; then
    echo "❌ Failed to get access token"
    exit 1
fi

echo "✅ Access token obtained: ${ACCESS_TOKEN:0:50}..."

# Step 2: Get user details
echo ""
echo "📤 Step 2: Get user details using access token"
DETAILS_RESPONSE=$(curl -s -X POST "$DETAILS_ENDPOINT" \
  -H "Content-Type: application/json" \
  -d "{
    \"access_token\": \"$ACCESS_TOKEN\"
  }")

echo "Details Response: $DETAILS_RESPONSE"

# Check if successful
if echo "$DETAILS_RESPONSE" | grep -q '"status":"success"'; then
    echo "✅ User details retrieved successfully!"
else
    echo "❌ Failed to get user details"
fi
```

## Windows PowerShell Example

```powershell
# Configuration
$BASE_URL = "http://localhost:8000"
$LOGIN_ENDPOINT = "$BASE_URL/api/customer/login/"
$DETAILS_ENDPOINT = "$BASE_URL/api/customer/details/"

Write-Host "🚀 Testing Get User Details API" -ForegroundColor Green
Write-Host "================================" -ForegroundColor Green

# Step 1: Login
Write-Host "📤 Step 1: Login to get access token" -ForegroundColor Yellow
$loginBody = @{
    username = "testuser"
    password = "testpass123"
} | ConvertTo-Json

$loginResponse = Invoke-RestMethod -Uri $LOGIN_ENDPOINT -Method POST -Body $loginBody -ContentType "application/json"

Write-Host "Login Response: $($loginResponse | ConvertTo-Json -Depth 10)"

# Extract access token
$accessToken = $loginResponse.access_token

if (-not $accessToken) {
    Write-Host "❌ Failed to get access token" -ForegroundColor Red
    exit 1
}

Write-Host "✅ Access token obtained: $($accessToken.Substring(0, 50))..." -ForegroundColor Green

# Step 2: Get user details
Write-Host ""
Write-Host "📤 Step 2: Get user details using access token" -ForegroundColor Yellow
$detailsBody = @{
    access_token = $accessToken
} | ConvertTo-Json

$detailsResponse = Invoke-RestMethod -Uri $DETAILS_ENDPOINT -Method POST -Body $detailsBody -ContentType "application/json"

Write-Host "Details Response: $($detailsResponse | ConvertTo-Json -Depth 10)"

# Check if successful
if ($detailsResponse.status -eq "success") {
    Write-Host "✅ User details retrieved successfully!" -ForegroundColor Green
} else {
    Write-Host "❌ Failed to get user details" -ForegroundColor Red
}
``` 