#!/usr/bin/env python3
"""
Test script to demonstrate the GetUserDetailsView API.
This API accepts an access token and returns user details with cart information.
"""

import requests
import json

# Configuration
BASE_URL = "http://localhost:8000"  # Change this to your server URL
LOGIN_ENDPOINT = f"{BASE_URL}/api/customer/login/"
USER_DETAILS_ENDPOINT = f"{BASE_URL}/api/customer/details/"

def test_login_and_get_user_details():
    """
    Test the complete flow: login to get token, then use token to get user details.
    """
    
    print("🚀 Testing Complete Flow: Login → Get User Details")
    print("=" * 60)
    
    # Step 1: Login to get access token
    login_data = {
        "username": "testuser",
        "password": "testpass123"
    }
    
    print("📤 Step 1: Login to get access token")
    print(f"   Endpoint: {LOGIN_ENDPOINT}")
    print(f"   Data: {json.dumps(login_data, indent=2)}")
    print()
    
    try:
        login_response = requests.post(LOGIN_ENDPOINT, json=login_data)
        
        if login_response.status_code in [200, 201]:
            login_data = login_response.json()
            access_token = login_data.get('access_token')
            
            print("✅ Login successful!")
            print(f"   Access Token: {access_token[:50]}...")
            print(f"   Customer ID: {login_data.get('customer_id')}")
            print()
            
            # Step 2: Use access token to get user details
            print("📤 Step 2: Get user details using access token")
            print(f"   Endpoint: {USER_DETAILS_ENDPOINT}")
            
            user_details_data = {
                "access_token": access_token
            }
            
            print(f"   Data: {json.dumps(user_details_data, indent=2)}")
            print()
            
            user_details_response = requests.post(USER_DETAILS_ENDPOINT, json=user_details_data)
            
            if user_details_response.status_code == 200:
                user_details = user_details_response.json()
                
                print("✅ User details retrieved successfully!")
                print(json.dumps(user_details, indent=2))
                print()
                
                # Compare the responses
                print("🔍 Comparison: Login vs Get User Details")
                print("=" * 40)
                
                login_cart = login_data.get('cart_details', {})
                details_cart = user_details.get('cart_details', {})
                
                print(f"Login Response - Cart Items: {login_cart.get('total_items', 0)}")
                print(f"Details Response - Cart Items: {details_cart.get('total_items', 0)}")
                print(f"Match: {login_cart.get('total_items') == details_cart.get('total_items')}")
                
                return True
            else:
                print("❌ Failed to get user details:")
                print(json.dumps(user_details_response.json(), indent=2))
                return False
                
        else:
            print("❌ Login failed:")
            print(json.dumps(login_response.json(), indent=2))
            return False
            
    except requests.exceptions.RequestException as e:
        print(f"❌ Request Error: {e}")
        return False

def test_invalid_token():
    """
    Test the API with an invalid token.
    """
    
    print("\n🧪 Testing Invalid Token")
    print("=" * 40)
    
    invalid_data = {
        "access_token": "invalid_token_here"
    }
    
    print(f"📤 Request Data: {json.dumps(invalid_data, indent=2)}")
    print()
    
    try:
        response = requests.post(USER_DETAILS_ENDPOINT, json=invalid_data)
        
        print(f"📥 Response Status: {response.status_code}")
        
        if response.status_code == 401:
            print("✅ Expected error for invalid token:")
            print(json.dumps(response.json(), indent=2))
        else:
            print("❌ Unexpected response:")
            print(json.dumps(response.json(), indent=2))
            
    except requests.exceptions.RequestException as e:
        print(f"❌ Request Error: {e}")

def test_missing_token():
    """
    Test the API without providing a token.
    """
    
    print("\n🧪 Testing Missing Token")
    print("=" * 40)
    
    empty_data = {}
    
    print(f"📤 Request Data: {json.dumps(empty_data, indent=2)}")
    print()
    
    try:
        response = requests.post(USER_DETAILS_ENDPOINT, json=empty_data)
        
        print(f"📥 Response Status: {response.status_code}")
        
        if response.status_code == 400:
            print("✅ Expected error for missing token:")
            print(json.dumps(response.json(), indent=2))
        else:
            print("❌ Unexpected response:")
            print(json.dumps(response.json(), indent=2))
            
    except requests.exceptions.RequestException as e:
        print(f"❌ Request Error: {e}")

def show_api_documentation():
    """
    Display API documentation for the new endpoint.
    """
    
    print("\n📚 API Documentation")
    print("=" * 50)
    print("""
🔗 Get User Details API
   Endpoint: POST /api/customer/details/
   
📤 Request Body:
   {
     "access_token": "your_jwt_access_token_here"
   }

📥 Response Structure (Success - 200):
   {
     "status": "success",
     "message": "User details retrieved successfully",
     "customer_id": 123,
     "user_details": {
       "id": 123,
       "username": "customer_username",
       "email": "customer@example.com",
       "customer_name": "Customer Name",
       "customer_phone": "1234567890",
       "wallet_amount": "100.00"
     },
     "cart_details": {
       "total_items": 5,
       "cart_items": [
         {
           "id": 1,
           "item_id": 456,
           "item_name": "Product Name",
           "item_sku": "SKU123",
           "item_price": "99.99",
           "item_image": "http://example.com/image.jpg",
           "quantity": 2,
           "total_price": "199.98"
         }
       ],
       "cart_count": 1
     }
   }

❌ Error Responses:
   
   Missing Token (400):
   {
     "status": "error",
     "message": "Access token is required."
   }
   
   Invalid Token (401):
   {
     "status": "error",
     "message": "Invalid or expired access token."
   }
   
   User Not Found (404):
   {
     "status": "error",
     "message": "User not found."
   }

🔧 Usage Examples:
   
   cURL:
   curl -X POST http://localhost:8000/api/customer/details/ \\
     -H "Content-Type: application/json" \\
     -d '{"access_token": "your_token_here"}'
   
   JavaScript:
   fetch('/api/customer/details/', {
     method: 'POST',
     headers: {'Content-Type': 'application/json'},
     body: JSON.stringify({access_token: 'your_token_here'})
   })
   
   Python:
   requests.post('/api/customer/details/', 
     json={'access_token': 'your_token_here'})
""")

if __name__ == "__main__":
    print("🚀 Get User Details API - Test Suite")
    print("=" * 60)
    
    # Show documentation first
    show_api_documentation()
    
    # Run tests
    success = test_login_and_get_user_details()
    test_invalid_token()
    test_missing_token()
    
    if success:
        print("\n✨ All tests completed successfully!")
    else:
        print("\n⚠️  Some tests failed. Check the output above.") 