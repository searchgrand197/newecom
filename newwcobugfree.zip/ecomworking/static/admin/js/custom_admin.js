// Custom Admin JavaScript for Enhanced File Upload Experience

document.addEventListener('DOMContentLoaded', function() {
    
    // File upload validation and feedback
    const fileInputs = document.querySelectorAll('input[type="file"]');
    
    fileInputs.forEach(function(input) {
        input.addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                // Show file info
                const fileInfo = document.createElement('div');
                fileInfo.className = 'file-info';
                fileInfo.innerHTML = `
                    <small style="color: #007cba; margin-top: 5px; display: block;">
                        Selected: ${file.name} (${(file.size / 1024 / 1024).toFixed(2)} MB)
                    </small>
                `;
                
                // Remove existing file info
                const existingInfo = input.parentNode.querySelector('.file-info');
                if (existingInfo) {
                    existingInfo.remove();
                }
                
                // Add new file info
                input.parentNode.appendChild(fileInfo);
                
                // Validate file size
                const isImage = input.name.includes('image');
                const maxSize = isImage ? 5 : 50; // 5MB for images, 50MB for videos
                
                if (file.size > maxSize * 1024 * 1024) {
                    fileInfo.innerHTML = `
                        <small style="color: #dc3545; margin-top: 5px; display: block;">
                            ⚠️ File too large! Maximum size is ${maxSize}MB
                        </small>
                    `;
                }
                
                // Validate file type
                const isValidType = isImage ? 
                    file.type.startsWith('image/') : 
                    file.type.startsWith('video/');
                
                if (!isValidType) {
                    fileInfo.innerHTML = `
                        <small style="color: #dc3545; margin-top: 5px; display: block;">
                            ⚠️ Invalid file type! Please select a ${isImage ? 'image' : 'video'} file
                        </small>
                    `;
                }
            }
        });
    });
    
    // Enhanced image preview functionality
    const imagePreviews = document.querySelectorAll('.field-image1_preview img, .field-image2_preview img, .field-image3_preview img');
    
    imagePreviews.forEach(function(img) {
        img.addEventListener('click', function() {
            // Create modal for larger image view
            const modal = document.createElement('div');
            modal.style.cssText = `
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0,0,0,0.8);
                display: flex;
                justify-content: center;
                align-items: center;
                z-index: 9999;
                cursor: pointer;
            `;
            
            const modalImg = document.createElement('img');
            modalImg.src = img.src;
            modalImg.style.cssText = `
                max-width: 90%;
                max-height: 90%;
                object-fit: contain;
                border-radius: 8px;
            `;
            
            modal.appendChild(modalImg);
            document.body.appendChild(modal);
            
            // Close modal on click
            modal.addEventListener('click', function() {
                document.body.removeChild(modal);
            });
        });
        
        // Add hover effect
        img.style.cursor = 'pointer';
    });
    
    // Form validation feedback
    const form = document.querySelector('#item_form');
    if (form) {
        form.addEventListener('submit', function(e) {
            const fileInputs = form.querySelectorAll('input[type="file"]');
            let hasErrors = false;
            
            fileInputs.forEach(function(input) {
                const file = input.files[0];
                if (file) {
                    const isImage = input.name.includes('image');
                    const maxSize = isImage ? 5 : 50;
                    
                    if (file.size > maxSize * 1024 * 1024) {
                        hasErrors = true;
                        showError(`File ${file.name} is too large. Maximum size is ${maxSize}MB.`);
                    }
                    
                    const isValidType = isImage ? 
                        file.type.startsWith('image/') : 
                        file.type.startsWith('video/');
                    
                    if (!isValidType) {
                        hasErrors = true;
                        showError(`File ${file.name} is not a valid ${isImage ? 'image' : 'video'} file.`);
                    }
                }
            });
            
            if (hasErrors) {
                e.preventDefault();
            }
        });
    }
    
    // Helper function to show errors
    function showError(message) {
        const errorDiv = document.createElement('div');
        errorDiv.className = 'messagelist';
        errorDiv.innerHTML = `
            <li class="error">${message}</li>
        `;
        
        const existingMessages = document.querySelector('.messagelist');
        if (existingMessages) {
            existingMessages.appendChild(errorDiv.querySelector('li'));
        } else {
            document.querySelector('.content').insertBefore(errorDiv, document.querySelector('.content').firstChild);
        }
    }
    
    // Add helpful tooltips
    const helpTexts = {
        'image1': 'Upload the main product image (JPG, PNG, GIF, max 5MB)',
        'image2': 'Upload a secondary product image (JPG, PNG, GIF, max 5MB)',
        'image3': 'Upload a third product image (JPG, PNG, GIF, max 5MB)',
        'video': 'Upload a product video (MP4, AVI, MOV, max 50MB)'
    };
    
    Object.keys(helpTexts).forEach(function(fieldName) {
        const field = document.querySelector(`[name="${fieldName}"]`);
        if (field) {
            field.title = helpTexts[fieldName];
        }
    });
}); 