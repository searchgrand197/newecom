#!/usr/bin/env python3
"""
Test script to demonstrate the updated customer login API with cart details.
This script shows how the API now returns cart information along with user details.
"""

import requests
import json

# Configuration
BASE_URL = "http://localhost:8000"  # Change this to your server URL
API_ENDPOINT = f"{BASE_URL}/api/customer/login/"

def test_customer_login_with_cart():
    """
    Test the customer login API to see cart details in the response.
    """
    
    # Test data for login
    test_data = {
        "username": "testuser",
        "password": "testpass123"
    }
    
    print("🧪 Testing Customer Login API with Cart Details")
    print("=" * 50)
    print(f"📡 API Endpoint: {API_ENDPOINT}")
    print(f"📤 Request Data: {json.dumps(test_data, indent=2)}")
    print()
    
    try:
        # Make the API request
        response = requests.post(API_ENDPOINT, json=test_data)
        
        print(f"📥 Response Status: {response.status_code}")
        print(f"📥 Response Headers: {dict(response.headers)}")
        print()
        
        if response.status_code in [200, 201]:
            # Parse the response
            data = response.json()
            
            print("✅ SUCCESS - API Response:")
            print(json.dumps(data, indent=2))
            print()
            
            # Extract and display cart details
            if 'cart_details' in data:
                cart_details = data['cart_details']
                print("🛒 Cart Details Summary:")
                print(f"   • Total Items: {cart_details.get('total_items', 0)}")
                print(f"   • Cart Count: {cart_details.get('cart_count', 0)}")
                print(f"   • Cart Items: {len(cart_details.get('cart_items', []))}")
                
                if cart_details.get('cart_items'):
                    print("\n📦 Individual Cart Items:")
                    for i, item in enumerate(cart_details['cart_items'], 1):
                        print(f"   {i}. {item['item_name']} (SKU: {item['item_sku']})")
                        print(f"      Quantity: {item['quantity']}")
                        print(f"      Price: ₹{item['item_price']}")
                        print(f"      Total: ₹{item['total_price']}")
                        if item.get('item_image'):
                            print(f"      Image: {item['item_image']}")
                        print()
            else:
                print("⚠️  No cart details found in response")
                
        else:
            print("❌ ERROR - API Response:")
            print(json.dumps(response.json(), indent=2))
            
    except requests.exceptions.ConnectionError:
        print("❌ Connection Error: Could not connect to the server.")
        print("   Make sure your Django server is running on the specified URL.")
    except requests.exceptions.RequestException as e:
        print(f"❌ Request Error: {e}")
    except json.JSONDecodeError as e:
        print(f"❌ JSON Decode Error: {e}")
        print(f"   Raw Response: {response.text}")

def test_new_user_registration():
    """
    Test creating a new user to see empty cart details.
    """
    
    # Test data for new user
    test_data = {
        "username": "newuser123",
        "password": "newpass123"
    }
    
    print("\n🧪 Testing New User Registration (Auto Register)")
    print("=" * 50)
    print(f"📤 Request Data: {json.dumps(test_data, indent=2)}")
    print()
    
    try:
        # Make the API request
        response = requests.post(API_ENDPOINT, json=test_data)
        
        print(f"📥 Response Status: {response.status_code}")
        
        if response.status_code in [200, 201]:
            data = response.json()
            
            print("✅ SUCCESS - New User Response:")
            print(json.dumps(data, indent=2))
            print()
            
            # Check cart details for new user
            if 'cart_details' in data:
                cart_details = data['cart_details']
                print("🛒 New User Cart Details:")
                print(f"   • Total Items: {cart_details.get('total_items', 0)}")
                print(f"   • Cart Count: {cart_details.get('cart_count', 0)}")
                print(f"   • Cart Items: {len(cart_details.get('cart_items', []))}")
                
                if cart_details.get('total_items') == 0:
                    print("✅ Expected: Empty cart for new user")
                else:
                    print("⚠️  Unexpected: Cart has items for new user")
            else:
                print("⚠️  No cart details found in response")
                
        else:
            print("❌ ERROR - API Response:")
            print(json.dumps(response.json(), indent=2))
            
    except requests.exceptions.RequestException as e:
        print(f"❌ Request Error: {e}")

def show_api_documentation():
    """
    Display API documentation for the updated endpoint.
    """
    
    print("\n📚 API Documentation")
    print("=" * 50)
    print("""
🔗 Customer Login API (Updated with Cart Details)
   Endpoint: POST /api/customer/login/
   
📤 Request Body:
   {
     "username": "customer_username",
     "password": "customer_password"
   }

📥 Response Structure (Success - 200/201):
   {
     "status": "success",
     "message": "Login successful" | "New customer created and logged in",
     "access_token": "jwt_token_here",
     "refresh_token": "refresh_token_here",
     "customer_id": 123,
     "user_details": {
       "id": 123,
       "username": "customer_username",
       "email": "customer@example.com",
       "customer_name": "Customer Name",
       "customer_phone": "1234567890",
       "wallet_amount": "100.00"
     },
     "cart_details": {
       "total_items": 5,
       "cart_items": [
         {
           "id": 1,
           "item_id": 456,
           "item_name": "Product Name",
           "item_sku": "SKU123",
           "item_price": "99.99",
           "item_image": "http://example.com/image.jpg",
           "quantity": 2,
           "total_price": "199.98"
         }
       ],
       "cart_count": 1
     }
   }

🆕 New Features:
   • cart_details: Complete cart information
   • total_items: Sum of all item quantities
   • cart_items: Array of cart items with full details
   • cart_count: Number of unique items in cart
   • item_image: Full URL to product image
   • total_price: Calculated price for each item

🔧 Usage Examples:
   • Existing users: Returns their current cart
   • New users: Returns empty cart structure
   • Auto-registration: Creates account if user doesn't exist
""")

if __name__ == "__main__":
    print("🚀 Customer Login API with Cart Details - Test Suite")
    print("=" * 60)
    
    # Show documentation first
    show_api_documentation()
    
    # Run tests
    test_customer_login_with_cart()
    test_new_user_registration()
    
    print("\n✨ Test completed! Check the responses above for cart details.") 